<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Appreciate_Moneylo
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Money Lo</title>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/font.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/aos.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/slick.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/slick-theme.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/header-footer.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/home.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/responsive.css">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>

	<!-- ================================================
            Header Navbar Section Start
=====================================================-->
	<header class="fadeInDown navbar navbar_other_pages">
		<nav class=" navbar-expand-lg navbar-light">
			<div class="container-fluid">
				<a class="navbar-brand header_logo" href="<?php echo get_site_url(); ?>/home/"><img src="<?php echo get_template_directory_uri(); ?>/images/header_logo.png" alt="MoneyLo"></a>
				<div class="header_right_prt">
					<div class="collapse navbar-collapse" id="navbarMenu">
						<?php
						$directoryURI = $_SERVER['REQUEST_URI'];
						$path = parse_url($directoryURI, PHP_URL_PATH);
						$components = explode('/', $path);
						$first_part = $components[1];
						?>
						<ul class="navbar-nav mb-0" id="customNavMenus">
							<li class="nav-item ">
								<a class="nav-link <?php if ($first_part == "") {
														echo "active";
													} else {
														echo "noactive";
													} ?>" href="<?php echo get_site_url(); ?>">Home</a>
							</li>
							<li class="nav-item">
								<a class="nav-link <?php if ($first_part == "term-loan" || $first_part == "overdraft") {
																echo "active";
															} else {
																echo "noactive";
															} ?>"  style="cursor: pointer;">Products</a>
								<span class="drop_down_icon fa fa-angle-down"></span>
								<ul class="dropdown-item ">
									<li class="nav-item">
										<a class="nav-link" href="<?php echo get_site_url(); ?>/term-loan/">Terms Loans</a>
									</li>

									<li class="nav-item">
										<a class="nav-link" href="<?php echo get_site_url(); ?>/overdraft/">Overdraft</a>
									</li>
								</ul>
							</li>



							<li class="nav-item">
								<a class="nav-link <?php if ($first_part == "about") {
														echo "active";
													} else {
														echo "noactive";
													} ?>" href="<?php echo get_site_url(); ?>/about/">About</a>
							</li>
							<li class="nav-item">
								<a class="nav-link <?php if ($first_part == "blog") {
														echo "active";
													} else {
														echo "noactive";
													} ?>" href="<?php echo get_site_url(); ?>/blog/">Blog</a>
							</li>
							<li class="nav-item">
								<a class="nav-link Click-here" href="javascript:void();">Contact Us</a>
							</li>
							<li class="nav-item">
								<div class="common_btn">
									<a href="javascript:void();">Login</a>
								</div>
							</li>


						</ul>
					</div>
				</div>

				<div class="header_phone">
					<ul class="rightNav">
						<li class="round-btn rightNav-toggle" id="show-search-box">
							<div class="common_btn">
								<a href="javascript:void();">Login</a>
							</div>

						</li>
					</ul>

					<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu" aria-controls="navbarMenu" aria-expanded="false" aria-label="Toggle navigation">
						<div class="hamburger animated-icon2">
							<span></span>
							<span></span>
							<span></span>
						</div>
					</button>

				</div>


			</div>

			<div class="header_right_prt mobile-prt">
				<div class="collapse navbar-collapse" id="navbarMenu">
					<ul class="navbar-nav mb-0">
						<li class="nav-item">
							<a class="nav-link" aria-current="page" href="<?php echo get_site_url(); ?>/home/">Home</a>
						</li>


						<li class="nav-item">
							<a class="nav-link" style="cursor: pointer;">Products</a>
							<span class="drop_down_icon fa fa-angle-down"></span>
							<ul class="dropdown-item ">

								<li class="nav-item">
									<a class="nav-link" href="<?php echo get_site_url(); ?>/term-loan/">Terms Loan</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="<?php echo get_site_url(); ?>/overdraft/">Overdraft</a>
								</li>
							</ul>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo get_site_url(); ?>/about/">About</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo get_site_url(); ?>/blog/">Blog</a>
						</li>
						<li class="nav-item">
							<a class="nav-link Click-here" href="javascript:void();">Contact Us</a>
						</li>

					</ul>

				</div>
			</div>
		</nav>



		<form id="hidden-search-box" class="navbar-form hidden-search-box" role="search" style="display: none;">
			<div class="input-group add-on">
				<button type="submit" class="input-group-btn addon-btn">
					<svg class="hidden-search-box" width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M30 30L24.2857 24.2857M18.5714 27.1429C17.4458 27.1429 16.3312 26.9212 15.2913 26.4904C14.2514 26.0596 13.3064 25.4283 12.5105 24.6323C11.7146 23.8364 11.0832 22.8915 10.6525 21.8516C10.2217 20.8116 10 19.697 10 18.5714C10 17.4458 10.2217 16.3312 10.6525 15.2913C11.0832 14.2514 11.7146 13.3064 12.5105 12.5105C13.3064 11.7146 14.2514 11.0832 15.2913 10.6525C16.3312 10.2217 17.4458 10 18.5714 10C20.8447 10 23.0249 10.9031 24.6323 12.5105C26.2398 14.118 27.1429 16.2981 27.1429 18.5714C27.1429 20.8447 26.2398 23.0249 24.6323 24.6323C23.0249 26.2398 20.8447 27.1429 18.5714 27.1429Z" stroke="#111010" stroke-width="1.79167"></path>
					</svg>
				</button>
				<input class="form-control addon-text-box" placeholder="Search" name="s" type="text">

			</div>
		</form>
	</header>
	<!-- ================================================
            Header Section End
=====================================================-->