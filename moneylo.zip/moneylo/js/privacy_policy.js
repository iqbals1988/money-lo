 
/* privacy policy on scroll functionality */

    const ArrayOfSelectors = [
        '#section1',
        '#section2',
        '#section3',
        '#section4',
        '#section5',
        '#section6',
        '#section7',
        '#section8',
        '#section9',
        '#section10',
        '#section11',
    ];

    function handleListScroll(getListValue) {
        if (getListValue == 1) {
            $('.nav-1').addClass("addActive");
            $('.nav-2').removeClass("addActive");
            $('.nav-3').removeClass("addActive");
            $('.nav-4').removeClass("addActive");
            $('.nav-5').removeClass("addActive");
            $('.nav-6').removeClass("addActive");
            $('.nav-7').removeClass("addActive");
            $('.nav-8').removeClass("addActive");
            $('.nav-9').removeClass("addActive");
            $('.nav-10').removeClass("addActive");
            $('.nav-11').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[0],
                    offsetY: 120
                },
            });
        } else if (getListValue == 2) {
            $('.nav-2').addClass("addActive");
            $('.nav-1').removeClass("addActive");
            $('.nav-3').addClass("addActive");
            $('.nav-3').removeClass("addActive");
            $('.nav-4').removeClass("addActive");
            $('.nav-5').removeClass("addActive");
            $('.nav-6').removeClass("addActive");
            $('.nav-7').removeClass("addActive");
            $('.nav-8').removeClass("addActive");
            $('.nav-9').removeClass("addActive");
            $('.nav-10').removeClass("addActive");
            $('.nav-11').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[1],
                    offsetY: 120
                },
            });

        } else if (getListValue == 3) {
            $('.nav-3').addClass("addActive");
            $('.nav-2').removeClass("addActive");
            $('.nav-1').removeClass("addActive");
            $('.nav-4').removeClass("addActive");
            $('.nav-5').removeClass("addActive");
            $('.nav-6').removeClass("addActive");
            $('.nav-7').removeClass("addActive");
            $('.nav-8').removeClass("addActive");
            $('.nav-9').removeClass("addActive");
            $('.nav-10').removeClass("addActive");
            $('.nav-11').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[2],
                    offsetY: 120
                },
            });
        } else if (getListValue == 4) {
            $('.nav-4').addClass("addActive");
            $('.nav-3').removeClass("addActive");
            $('.nav-2').removeClass("addActive");
            $('.nav-1').removeClass("addActive");
            $('.nav-5').removeClass("addActive");
            $('.nav-6').removeClass("addActive");
            $('.nav-7').removeClass("addActive");
            $('.nav-8').removeClass("addActive");
            $('.nav-9').removeClass("addActive");
            $('.nav-10').removeClass("addActive");
            $('.nav-11').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[3],
                    offsetY: 120
                },
            });
        } else if (getListValue == 5) {
            $('.nav-5').addClass("addActive");
            $('.nav-4').removeClass("addActive");
            $('.nav-3').removeClass("addActive");
            $('.nav-2').removeClass("addActive");
            $('.nav-1').removeClass("addActive");
            $('.nav-6').removeClass("addActive");
            $('.nav-7').removeClass("addActive");
            $('.nav-8').removeClass("addActive");
            $('.nav-9').removeClass("addActive");
            $('.nav-10').removeClass("addActive");
            $('.nav-11').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[4],
                    offsetY: 120
                },
            });
        } else if (getListValue == 6) {
            $('.nav-6').addClass("addActive");
            $('.nav-5').removeClass("addActive");
            $('.nav-4').removeClass("addActive");
            $('.nav-3').removeClass("addActive");
            $('.nav-2').removeClass("addActive");
            $('.nav-1').removeClass("addActive");
            $('.nav-7').removeClass("addActive");
            $('.nav-8').removeClass("addActive");
            $('.nav-9').removeClass("addActive");
            $('.nav-10').removeClass("addActive");
            $('.nav-11').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[5],
                    offsetY: 120
                },
            });
        } else if (getListValue == 7) {
            $('.nav-7').addClass("addActive");
            $('.nav-6').removeClass("addActive");
            $('.nav-5').removeClass("addActive");
            $('.nav-4').removeClass("addActive");
            $('.nav-3').removeClass("addActive");
            $('.nav-2').removeClass("addActive");
            $('.nav-1').removeClass("addActive");
            $('.nav-8').removeClass("addActive");
            $('.nav-9').removeClass("addActive");
            $('.nav-10').removeClass("addActive");
            $('.nav-11').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[6],
                    offsetY: 120
                },
            });
        } else if (getListValue == 8) {
            $('.nav-8').addClass("addActive");
            $('.nav-7').removeClass("addActive");
            $('.nav-6').removeClass("addActive");
            $('.nav-5').removeClass("addActive");
            $('.nav-4').removeClass("addActive");
            $('.nav-3').removeClass("addActive");
            $('.nav-2').removeClass("addActive");
            $('.nav-1').removeClass("addActive");
            $('.nav-9').removeClass("addActive");
            $('.nav-10').removeClass("addActive");
            $('.nav-11').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[7],
                    offsetY: 120
                },
            });
        } else if (getListValue == 9) {
            $('.nav-9').addClass("addActive");
            $('.nav-8').removeClass("addActive");
            $('.nav-7').removeClass("addActive");
            $('.nav-6').removeClass("addActive");
            $('.nav-5').removeClass("addActive");
            $('.nav-4').removeClass("addActive");
            $('.nav-3').removeClass("addActive");
            $('.nav-2').removeClass("addActive");
            $('.nav-1').removeClass("addActive");
            $('.nav-10').removeClass("addActive");
            $('.nav-11').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[8],
                    offsetY: 120
                },
            });
        } else if (getListValue == 10) {
            $('.nav-10').addClass("addActive");
            $('.nav-9').removeClass("addActive");
            $('.nav-8').removeClass("addActive");
            $('.nav-7').removeClass("addActive");
            $('.nav-6').removeClass("addActive");
            $('.nav-5').removeClass("addActive");
            $('.nav-4').removeClass("addActive");
            $('.nav-3').removeClass("addActive");
            $('.nav-2').removeClass("addActive");
            $('.nav-1').removeClass("addActive");
            $('.nav-11').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[9],
                    offsetY: 120
                },
            });
        } else if (getListValue == 11) {
            $('.nav-11').addClass("addActive");
            $('.nav-10').removeClass("addActive");
            $('.nav-9').removeClass("addActive");
            $('.nav-8').removeClass("addActive");
            $('.nav-7').removeClass("addActive");
            $('.nav-6').removeClass("addActive");
            $('.nav-5').removeClass("addActive");
            $('.nav-4').removeClass("addActive");
            $('.nav-3').removeClass("addActive");
            $('.nav-2').removeClass("addActive");
            $('.nav-1').removeClass("addActive");
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[10],
                    offsetY: 120
                },
            });
        } else if (getListValue == 12) {
            gsap.to(window, {
                duration: 0.5,
                scrollTo: {
                    y: ArrayOfSelectors[11],
                    offsetY: 120
                },
            });
        }
    }


    $(document).ready(function () {
  $(window).on("scroll", function () {
    // Show & Hide Text On-Scroll
    if ($(window).scrollTop() > 6700) {
      $(".terms_list").fadeOut(500);
    } else {
      $(".terms_list").fadeIn(0);
    }
  });
});

  

 