<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Appreciate_Moneylo
 */

?>

	<section class="footer_section">
    <div class="container">
    <div class="row ">
        <div class="col-xl-6 col-lg-6 col-sm-6">
            <div class="footer_logo common_content">
				  <a class="navbar-brand header_logo" href="<?php echo get_site_url(); ?>/home/">
                		<img src="<?php echo get_template_directory_uri(); ?>/images/footer_logo.webp" alt="">
				</a>
                <p>by Appreciate</p>
            </div>
            <div class="footer_txt common_content">
                <p>Trusted Banking Lenders. Multiple Loan Options
                    Anytime, Anywhere <span>One App</span></p>
            </div>
            <ul class="social_networking_icon destop_Social_icon">
                <li>
                    <a href="">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/facebook.svg" alt="">
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/instagram.svg" alt="">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/linkedin.svg" alt="">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/x_icon.svg" alt="">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/youtube.svg" alt="">
                    </a>
                </li>
            </ul>
            <div class="copyright destop_Social_icon">© 2024. MoneyLo by Appreciate</div>
        </div>
        <div class="col-xl-6 col-lg-6  col-sm-6">
            <div class="footer_menu">
                <ul>
                    <li>
                        <a  href="<?php echo get_site_url(); ?>/about/">
                            About
                        </a>
                    </li>
                    <li>
                        <a  href="<?php echo get_site_url(); ?>/term-loan/">
                            Products
                        </a>
                    </li>
                    <li>
                        <a  href="<?php echo get_site_url(); ?>/blog/">
                            Blog
                        </a>
                    </li>
                    <li>
                        <a class="Click-here" href="javascript:void();">
                            Contact
                        </a>
                    </li>
                </ul>
                <ul>
                    <li>
                        <a  href="<?php echo get_site_url(); ?>/privacy-policy/">
                            Privacy policy
                        </a>
                    </li>
                    <li>
                        <a  href="<?php echo get_site_url(); ?>/terms-condition/">
                            Terms & conditions
                        </a>
                    </li>
                </ul>
            </div>

            <div class="google_app_btn">
                <a href="#" class="Googleplaystore">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/Googleplaystore.webp" alt="">
                </a>
                <a href="#" class="app_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/AppStore.webp" alt="">
                </a>
            </div>

            <ul class="social_networking_icon mobile_Social_icon">
                <li>
                    <a href="">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/facebook.svg" alt="">
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/instagram.svg" alt="">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/linkedin.svg" alt="">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/x_icon.svg" alt="">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/youtube.svg" alt="">
                    </a>
                </li>
            </ul>
            <div class="copyright mobile_Social_icon">© 2024. MoneyLo by Appreciate</div>

        </div>
    </div>
</div>
</section>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/slick.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/gsap-animations.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.7.0/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.7.0/ScrollToPlugin.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.7.0/ScrollTrigger.min.js"></script>

    <script src="<?php echo get_template_directory_uri(); ?>/js/custom.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/privacy_policy.js"></script>
<script>

    $('.numberonly').keypress(function (e) {
        var charCode = (e.which) ? e.which : event.keyCode
        if (String.fromCharCode(charCode).match(/[^0-9]/g))
            return false;
    });
    function IsEmail(email) {
            var regex =
/^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if (!regex.test(email)) {
                return false;
            }
            else {
                return true;
            }
        }
        function isValidMobileNumber(mobileNumber) {
  var mobileNumberPattern = /^[0-9]{10}$/;
  return mobileNumberPattern.test(mobileNumber);
}

	
</script>

<!-- <script>
	document.querySelectorAll(".nav-link").forEach((link) => {
    if (link.href === window.location.href) {
		link.classList.remove("active");
        link.classList.add("active");
       link.setAttribute("aria-current", "page");
    }
});
</script> -->

</div><!-- #page -->
<style>
.wpcf7-not-valid-tip:not(:nth-child(1)):not(:nth-child(2)) {display:none;}

	
    </style>

<?php wp_footer(); ?>

</body>
</html>