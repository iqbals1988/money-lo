<?php

/*
Template Name: Product category Page
*/

get_header();
?>

	<!-- ================================================
            Banner Section Start
=====================================================-->
<div class="home_banner_section">
      
        
      <div class="home_banner_main banner_slider product_category_banner">
          <div class="home_banner_div">
              <img src="<?php echo get_template_directory_uri(); ?>/images/product_category.jpg" alt="">
              <div class="container">
                  <div class="banner_center">
                      <h1 class="banner_heading banner_conent">
                      Keep your business moving forward  & upward</h1>
                      <div class="product_sub_heading">Take control over your cashflow with Overdraft by MoneyLo</div>
                    
                  </div>

                  <div class="apply_btn">
                      <a href="" class="common_btn">Apply Now</a>
                  </div>
              </div>
          </div>

          <div class="home_banner_div">
              <img src="<?php echo get_template_directory_uri(); ?>/images/product_category.jpg" alt="">
              <div class="container">
                  <div class="banner_center">
                      <h1 class="banner_heading banner_conent">
                      Keep your business moving forward  & upward</h1>
                      <div class="product_sub_heading">Take control over your cashflow with Overdraft by MoneyLo</div>
                     
                  </div>

                  <div class="apply_btn">
                      <a href="" class="common_btn">Apply Now</a>
                  </div>
              </div>
          </div>


</div>
<!-- ================================================
          Banner Section End
=====================================================-->
    <!-- ================================================
            Interest Section Start
=====================================================-->
<section class="interest_section">
    <div class="container">
        <div class="interest_main ">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-sm-4 interest_div common_bg_heading">
                    <div class="interest_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Asset1.png" alt="">
                    </div>
                    <h2>
                        Amount upto ₹25 Lakhs
                    </h2>
                </div>

                <div class="col-xl-4 col-lg-4 col-sm-4 interest_div common_bg_heading">
                    <div class="interest_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Asset2.png" alt="">
                    </div>
                    <h2>
                    Tenure upto 15 years
                    </h2>
                </div>
            

                <div class="col-xl-4 col-lg-4 col-sm-4 interest_div common_bg_heading">
                    <div class="interest_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Asset3.png" alt="">
                    </div>
                    <h2>
                    Starts @10.5% interest rate
                    </h2>
                </div>
                </div>
            </div>

            </div>
        </div>
    </div>
</section>
<!-- ================================================
        Interest Section End
=====================================================-->

    <!-- ================================================
            credit_unlock_section Section Start
=====================================================-->
<section class="credit_section">
    <div class="container">
        <div class="common_heading top_content">Apply in 4 easy steps</div>
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-sm-3  credit_heading_div">
                <div class="credit_box">
                   <div class="credit_img">
                       <img src="<?php echo get_template_directory_uri(); ?>/images/BusinessEligible.webp" alt="">
                    </div>
                </div>
                <div class="credit_txt_box">
                    <div class="credit_small_box">1</div>
                    <div class="credit_txt">Instant eligibility
                        check</div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-sm-3 credit_heading_div">
                <div class="credit_box">
                    <div class="credit_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/IncomeVerification.png" alt="">
                     </div>
                </div>
                <div class="credit_txt_box">
                    <div class="credit_small_box">2</div>
                    <div class="credit_txt">KYC & Income
                        verification</div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-sm-3  credit_heading_div">
                <div class="credit_box">
                    <div class="credit_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/InstantApproval.png" alt="">
                     </div>
                </div>
                <div class="credit_txt_box">
                    <div class="credit_small_box">3</div>
                    <div class="credit_txt">Loan
                        application</div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-sm-3 credit_heading_div">
                <div class="credit_box">
                    <div class="credit_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Disbursement.png" alt="">
                     </div>
                </div>
                <div class="credit_txt_box">
                    <div class="credit_small_box">4</div>
                    <div class="credit_txt">Quick
                        disbursal</div>
                </div>
            </div>
        </div>

</section>
<!-- ================================================
        credit_unlock_section Section End
=====================================================-->

    <!-- ================================================
           Terms Loan Option Section Start
=====================================================-->
<section class="terms_loan_section">
    <div class="container">
        <div class="common_heading  top_content">Why choose Overdraft by MoneyLo</div>
 
        <div class="row">
            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="terms_loan_box">
                    <div class="terms_loan_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/term_loan/Flexible.png" alt="">
                    </div>
                    <div class="terms_loan_txt common_bg_heading common_content">
                        <h2>Flexible Credit Line</h2>
                        <p>Access funds, without being tied to a fixed loan amount or repayment schedule</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="terms_loan_box">
                    <div class="terms_loan_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/term_loan/Collateral.png" alt="">
                    </div>
                    <div class="terms_loan_txt common_bg_heading common_content">
                        <h2>No Collateral Required</h2>
                        <p>Get an extended credit line conveniently without collateral</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="terms_loan_box">
                    <div class="terms_loan_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/term_loan/Quick.png" alt="">
                    </div>
                    <div class="terms_loan_txt common_bg_heading common_content">
                        <h2>Quick Approval</h2>
                        <p>Ensure easy monthly repayments and financial stability</p>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="terms_loan_box">
                    <div class="terms_loan_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/term_loan/LowInterest.png" alt="">
                    </div>
                    <div class="terms_loan_txt common_bg_heading common_content">
                        <h2>Competitive Terms & Interest Rates</h2>
                        <p>Find the right overdraft facility from our network of trusted lenders</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="terms_loan_box">
                    <div class="terms_loan_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/term_loan/Dedicated.png" alt="">
                    </div>
                    <div class="terms_loan_txt common_bg_heading common_content">
                        <h2>Dedicated Support</h2>
                        <p>Get the support at every step from application to repayment with our team of dedicated experts</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="terms_loan_box">
                    <div class="terms_loan_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/term_loan/Reputable.png" alt="">
                    </div>
                    <div class="terms_loan_txt common_bg_heading common_content">
                        <h2>Reputable Lending Partners</h2>
                        <p>Access overdraft facilities from India’s most trusted banks and NBFCs — all in one place</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
    <!-- ================================================
           Terms Loan Option Section End
=====================================================-->

    <!-- ================================================
            Loan Option Section Start
=====================================================-->
<section class="loan_option_section product_loan">
    <div class="loan_option_main" id="tabs">
        <div class="loan_option_left">
            <div class="txt_box common_sub_heading">
                <ul class="loan_accordion">
                    <li class="accordion-list" data-index="0">
                        <span href="#tab1">
                            <div class="terms_heading common_bold_heading">Stay afloat when it <br>
                                matters the most</div>
                            <div class="active">
                            <div class="loan_option_step common_content">
                                <p>Cover payroll, restock inventory, and manage overhead costs during slow periods with Overdraft by MoneyLo</p>
                            </div>
                            <a href="" class="common_btn">Apply Now</a>
                        </div>
                    </span>
                    </li>

                    <li class="accordion-list" data-index="1">
                        <span href="#tab2">
                            <div class="terms_heading common_bold_heading">Be prepared for <br>
                            the unexpected</div>
                            <div class="active">
                            <div class="loan_option_step common_content">
                            <p>Cover payroll, restock inventory, and manage overhead costs during slow periods with Overdraft by MoneyLo</p>
                            </div>
                            <a href="" class="common_btn">Apply Now</a>
                            </div>
                        </span>
                    </li>

                    <li class="accordion-list" data-index="1">
                        <span href="#tab3">
                            <div class="terms_heading common_bold_heading">Keep your business <br>
                            thriving</div>
                            <div class="active">
                            <div class="loan_option_step common_content">
                            <p>Cover payroll, restock inventory, and manage overhead costs during slow periods with Overdraft by MoneyLo</p>
                            </div>
                            <a href="" class="common_btn">Apply Now</a>
                            </div>
                        </span>
                    </li>

                </ul>
            </div>
        </div>
        <div class="loan_option_right">
            <div class="" id="tab1">
            <img src="<?php echo get_template_directory_uri(); ?>/images/loan_option3.png" alt="Loan_images">
        </div>
        <div class="hide" id="tab2">
            <img src="<?php echo get_template_directory_uri(); ?>/images/loan_option2.png" alt="Loan_images">
        </div>
        <div class="hide" id="tab3">
            <img src="<?php echo get_template_directory_uri(); ?>/images/loan_option2.webp" alt="Loan_images">
        </div>
       
        </div>
    </div>
</section>

<!-- ================================================
        Loan Option Section Start
=====================================================-->

   <!-- ================================================
            Quicker Section Start
=====================================================-->
<section class="quicker_section product_category_quicker">
    <div class="container">
<!--         <div class="common_sub_heading">
            <h3>Why MoneyLo</h3>
        </div> -->
        <div class="common_heading  top_content">Meet unexpected expenses</div>
    </div>

    <div class="custom_wrapper">
        <div class="quicker_main quicker_slider">
            <div class="quicker_box common_content">
                <div class="credit_small_box">1</div>
                <div class="quicker_heading">Fastest and easiest loan application process</div>
                <p>Access quick and easy funds for emergencies and short-term cash requirements without paperwork</p>
            </div>

            <div class="quicker_box common_content">
                <div class="credit_small_box">2</div>
                <div class="quicker_heading">Manage cashflow fluctuations</div>
                <p>Get a ready credit line to smoothen out your cash flow without any business disruption</p>
            </div>

            <div class="quicker_box common_content">
                <div class="credit_small_box">3</div>
                <div class="quicker_heading">Pay interest only on the amount used</div>
                <p>Get cost-effective financing – pay interest only as and when you use the overdraft funds</p>
            </div>

            <div class="quicker_box common_content">
                <div class="credit_small_box">4</div>
                <div class="quicker_heading">Convenient fund transfers</div>
                <p>Access our user-friendly app with online banking for convenient fund transfers and account management.</p>
            </div>

            <div class="quicker_box common_content">
                <div class="credit_small_box">5</div>
                <div class="quicker_heading">Avoid declined transactions</div>
                <p>Get automatic overdraft protection to avoid declined transactions and unexpected fees.</p>
            </div>
        </div>

        <ul class="slider_ul">
            <li class="sprev-arrow slick-arrow" style="">
                <svg xmlns="http://www.w3.org/2000/svg" width="61" height="16" viewBox="0 0 61 16" fill="none">
                    <path
                        d="M0.292892 7.29289C-0.0976333 7.68341 -0.0976334 8.31658 0.292892 8.7071L6.65685 15.0711C7.04738 15.4616 7.68054 15.4616 8.07107 15.0711C8.46159 14.6805 8.46159 14.0474 8.07107 13.6569L2.41421 8L8.07107 2.34314C8.46159 1.95262 8.46159 1.31945 8.07107 0.92893C7.68054 0.538405 7.04738 0.538405 6.65685 0.92893L0.292892 7.29289ZM61 7L1 7L1 9L61 9L61 7Z"
                        fill="#605EBC" />
                </svg>
            </li>
            <li class="snext-arrow slick-arrow" style="">
                <svg xmlns="http://www.w3.org/2000/svg" width="61" height="16" viewBox="0 0 61 16" fill="none">
                    <path
                        d="M60.7071 7.29289C61.0976 7.68341 61.0976 8.31658 60.7071 8.7071L54.3431 15.0711C53.9526 15.4616 53.3195 15.4616 52.9289 15.0711C52.5384 14.6805 52.5384 14.0474 52.9289 13.6569L58.5858 8L52.9289 2.34314C52.5384 1.95262 52.5384 1.31945 52.9289 0.92893C53.3195 0.538405 53.9526 0.538405 54.3431 0.92893L60.7071 7.29289ZM-4.37114e-08 7L60 7L60 9L4.37114e-08 9L-4.37114e-08 7Z"
                        fill="#605EBC" />
                </svg>
            </li>
        </ul>
    </div>
</section>
<!-- ================================================
        Quicker Section End
=====================================================-->

<!-- ================================================
        Checklist Section Start
=====================================================-->
<section class="checklist_section">
    <div class="container">
        <div class="common_heading top_content">Document checklist</div>

        <div class="row">
            <div class="col-xl-3 col-lg-3 col-sm-4 checklist_div">
                <div class="checklist_img"><img src="<?php echo get_template_directory_uri(); ?>/images/Checklist.png" alt=""></div>
                <div class="checklist_txt">KYC <br> Documents</div>
            </div>

            <div class="col-xl-3 col-lg-3 col-sm-4 checklist_div">
                <div class="checklist_img"><img src="<?php echo get_template_directory_uri(); ?>/images/Checklist.png" alt=""></div>
                <div class="checklist_txt">Udyam <br> Certificate</div>
            </div>

            <div class="col-xl-3 col-lg-3 col-sm-4 checklist_div">
                <div class="checklist_img"><img src="<?php echo get_template_directory_uri(); ?>/images/Checklist.png" alt=""></div>
                <div class="checklist_txt">Last 2 years <br> ITR</div>
            </div>

            <div class="col-xl-3 col-lg-3 col-sm-4 checklist_div">
                <div class="checklist_img"><img src="<?php echo get_template_directory_uri(); ?>/images/Checklist.png" alt=""></div>
                <div class="checklist_txt">Last 12 months bank  <br>statements</div>
            </div>
        </div>
    </div>
</section>
<!-- ================================================
        Checklist Section End
=====================================================-->

<!-- ================================================
            FAQ Section Start
=====================================================-->
<section class="common_padding frequently_section">
    <div class="container">
        <div class="common_sub_heading top_content">
            <h3>Frequently Asked Questions</h3>
        </div>

        <div class="faq_accordion_main">
            <div class="faq_accordion">
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">What types of loans are available through MoneyLo?</p>
                    </button>
                    <div class="accordion-content answer">
                        <p>MoneyLo currently offers term loans to help MSMEs get instant access to funds and grow their businesses. We are also actively 
							working on expanding our offerings to include overdraft (OD) facilities and other types of loans in the near future.</p>
                    </div>
                </div>
              
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">Can I track the status of my loan application?</p>
                    </button>
                    <div class="accordion-content answer">
                        <p>Yes, MoneyLo offers a real-time tracking feature that allows you to monitor the status of your loan application. 
							You will receive timely updates on each stage of the process.</p>
                    </div>
                </div>
               
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">Is my personal and business information secure on MoneyLo?</p>
                    </button>
                    <div class="accordion-content answer">
                        <p>Yes, we prioritize the security and confidentiality of your data. The MoneyLo app uses strong encryption and security measures to protect your information.</p>
                    </div>
                </div>

                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title"> How long does it take to get the loan disbursed? </p>
                    </button>
                    <div class="accordion-content answer">
                        <p>The turnaround time (TAT) for disbursing the loan is typically 5 working days after submission.</p>
                    </div>
                </div>
                
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">What happens if a customer misses their loan payment? </p>
                    </button>
                    <div class="accordion-content answer">
                        <p>If a customer misses a loan payment, it may affect their CIBIL score and result in additional penalties. 
							It's advisable to contact customer support to discuss potential solutions.</p>
                    </div>
                </div>
                
            </div>

            <div class="faq_accordion">
                
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">Why should I register with Udyam?</p>
                    </button>
                    <div class="accordion-content answer ">
                        <p>Udyam is a dedicated platform designed to streamline and support MSMEs in India. By registering with Udyam, 
							you gain access to a range of essential services and benefits that can help your business thrive.</p>
                    </div>
                </div>
               
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">Is stamping and signing done digitally during the registration process?</p>
                    </button>
                    <div class="accordion-content answer">
                        <p>Yes, MoneyLo facilitates a fully digital registration process. Stamping and signing of documents are done electronically, 
							ensuring a seamless and paperless experience for users.</p>
                    </div>
                </div>
               
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">What if I encounter issues during the loan application process?</p>
                    </button>
                    <div class="accordion-content answer">
                        <p>MoneyLo has a dedicated customer support channel to assist you with any queries or issues. Reach out to our support team through the help centre for prompt assistance.</p>
                    </div>
                </div>
                
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">What is the range between which customers can opt for a loan? </p>
                    </button>
                    <div class="accordion-content answer">
                        <p>Customers can opt for a loan amount ranging from 50,000 to 25,00,000 INR.</p>
                    </div>
                </div>
              
            </div>
        </div>
</section>
<!-- ================================================
        FAQ Section End
=====================================================-->
	
	<!-- ================================================
            Terms Condition Section End
=====================================================-->

<!-- ================================================
   Modal pop up section start
=====================================================-->

<div class="custom-model-main">
    <div class="custom-model-inner container">
         <div class="close-btn">×</div>
        <div class="row">
            <div class="col-xl-6">
                <div class="model_contact_details">
               <div class="common_heading">
               We would love to hear from you
               </div> 
               <div class="modal_custom_content">
               Have something nice or not so nice to say? Do you have any questions? Reach out to us, we’d love to start a dialogue with you.
               </div>
               <ul class="mail_list">
                <li class="mail_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/mail.svg" alt="">
                </li>
                    <li class="mail_text"><a target="_blank" href="mailto:helpdesk@ppreciate.com">helpdesk@appreciate.com</a></li>
               </ul>
               <ul class="call_list">
                <li class="call_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/call.svg" alt="">
                </li>
                <li class="call_text"><a href="tel:+91-7039325849">+91 70393 25849</a><br><span>(9 am to 9 pm)</span></li>
               </ul>
               </div>
               <div class="model_left_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/contact_box.png" alt="">
               </div>
            </div>
            <div class="col-xl-6">
                <div class="modal_form">
                	 <?php echo do_shortcode('[contact-form-7 id="395c14b" title="Contact form"]');?>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-overlay"></div>
</div>  
<!-- ================================================
   Modal pop up section end
=====================================================-->


<?php get_footer();?>