<?php

/*
Template Name: Home page
*/

get_header();
?>
	<!-- ================================================
            Banner Section Start
=====================================================-->
<div class="home_banner_section">
      
        
      <div class="home_banner_main banner_slider">
          <div class="home_banner_div">
              <img src="<?php echo get_template_directory_uri(); ?>/images/home_banner.webp" alt="">
              <div class="container">
                  <div class="banner_center">
                      <h1 class="banner_heading banner_conent">
                          Get Business Loans<span> in under <br> 29 minutes</span></h1>
                      <ul class="breadcum">
                          <li>
                              <a href="<?php echo get_site_url(); ?>/term-loan/">
                                  Term Loans
                              </a>
                          </li>
                          <li>
                              <a href="<?php echo get_site_url(); ?>/overdraft/">
                                  Overdraft
                              </a>
                          </li>
                      </ul>

                  </div>

                  <div class="apply_btn">
                      <a href="" class="common_btn">Apply Now</a>
                  </div>
              </div>
          </div>

          <div class="home_banner_div">
              <img src="<?php echo get_template_directory_uri(); ?>/images/home_banner_2.webp" alt="">
              <div class="container">
                  <div class="banner_center">
                      <h1 class="banner_heading banner_conent banner_two">
						  Get loans on the go <span> - simple, smart, </br> and fast</span></h1>
                      <ul class="breadcum">
                          <li>
                              <a href="<?php echo get_site_url(); ?>/term-loan/">
                                  Term Loans
                              </a>
                          </li>
                          <li>
                              <a href="<?php echo get_site_url(); ?>/overdraft/">
                                  Overdraft
                              </a>
                          </li>
                      </ul>

                  </div>

    
                  <div class="apply_btn">
                      <a href="" class="common_btn">Apply Now</a>
                  </div>
			  
			  
              </div>
          </div>

	
	  <div class="home_banner_div">
              <img src="<?php echo get_template_directory_uri(); ?>/images/home_banner_3.webp" alt="">
              <div class="container">
                  <div class="banner_center">
                      <h1 class="banner_heading banner_conent banner_two">
						  No collateral? No problem!<span> get quick funds for all </br> your business needs</span></h1>
                      <ul class="breadcum">
                          <li>
                              <a href="<?php echo get_site_url(); ?>/term-loan/">
                                  Term Loans
                              </a>
                          </li>
                          <li>
                              <a href="<?php echo get_site_url(); ?>/overdraft/">
                                  Overdraft
                              </a>
                          </li>
                      </ul>

                  </div>

    
                  <div class="apply_btn">
                      <a href="" class="common_btn">Apply Now</a>
                  </div>
			  
			  
              </div>
          </div>
	

</div>
<!-- ================================================
          Banner Section End
=====================================================-->
    <!-- ================================================
            Interest Section Start
=====================================================-->
<section class="interest_section">
    <div class="container">
        <div class="interest_main ">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-sm-4 interest_div common_bg_heading">
                    <div class="interest_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/LowInterest.png" alt="">
                    </div>
                    <h2>
                        Low Interest Rates
                    </h2>
                </div>

                <div class="col-xl-4 col-lg-4 col-sm-4 interest_div common_bg_heading">
                    <div class="interest_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/MinDocuments.png" alt="">
                    </div>
                    <h2>
                        Minimal Documentation
                    </h2>
                </div>
            

                <div class="col-xl-4 col-lg-4 col-sm-4 interest_div common_bg_heading">
                    <div class="interest_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/100Digital.png" alt="">
                    </div>
                    <h2>
                        Personalised offering
                    </h2>
                </div>
                </div>
            </div>

            </div>
        </div>
    </div>
</section>
<!-- ================================================
        Interest Section End
=====================================================-->

    <!-- ================================================
            credit_unlock_section Section Start
=====================================================-->
<section class="credit_section">
    <div class="container">
        <div class="common_heading top_content">Unlock credit up to ₹10 Crore in 4 easy steps</div>
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-sm-3  credit_heading_div">
                <div class="credit_box">
                   <div class="credit_img">
                       <img src="<?php echo get_template_directory_uri(); ?>/images/BusinessEligible.webp" alt="">
                    </div>
                </div>
                <div class="credit_txt_box">
                    <div class="credit_small_box">1</div>
                    <div class="credit_txt">Instant eligibility
                        check</div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-sm-3 credit_heading_div">
                <div class="credit_box">
                    <div class="credit_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/IncomeVerification.png" alt="">
                     </div>
                </div>
                <div class="credit_txt_box">
                    <div class="credit_small_box">2</div>
                    <div class="credit_txt">KYC & Income
                        verification</div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-sm-3  credit_heading_div">
                <div class="credit_box">
                    <div class="credit_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/InstantApproval.png" alt="">
                     </div>
                </div>
                <div class="credit_txt_box">
                    <div class="credit_small_box">3</div>
                    <div class="credit_txt">Loan
                        application</div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-sm-3 credit_heading_div">
                <div class="credit_box">
                    <div class="credit_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Disbursement.png" alt="">
                     </div>
                </div>
                <div class="credit_txt_box">
                    <div class="credit_small_box">4</div>
                    <div class="credit_txt">Quick
                        disbursal</div>
                </div>
            </div>
        </div>

</section>
<!-- ================================================
        credit_unlock_section Section End
=====================================================-->

    <!-- ================================================
            App Section Start
=====================================================-->
<section class="app_section">
    <div class="app_main">
        <div class="app_left">
            <div class="app_img">
                <div class="img_app">
                <img src="<?php echo get_template_directory_uri(); ?>/images/app_img.webp" alt="">
            </div>
        </div>
        </div>
        <div class="app_right">
            <div class="app_right_box">
                <div class="get_heading">
                    Trusted Banking Lenders
                    Multiple Loan Options
                    Anytime, Anywhere
                </div>
                <div class="common_bold_heading border-txt">One App</div>
                <div class="app_scan_txt">Scan the QR to check your loan eligibility</div>
                <div class="row ">
                    <div class="col-xl-6 col-lg-6 col-sm-6 scan_code">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/scan.svg" alt="">
                    </div>
                    <div class="col-xl-6 col-lg-6 col-sm-6 social_networking">
                        <div class="Googleplaystore">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/AppStore.webp" alt="">
                        </div>
                        <div class="app_img">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/Googleplaystore.webp" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ================================================
        App Section End
=====================================================-->

    <!-- ================================================
            Approval Section Start
=====================================================-->
<section class="approval_section">
    <div class="container">
        <div class="box-section">
            <div class="box-bg">
                <div class="box-img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/29Min.webp" alt="">
                </div>
                <div class="common_bg_heading">
                    <h2>Approval under 29 min</h2>
                </div>
            </div>
            <div class="box-bg">
                <div class="box-img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/Quick.webp" alt="">
                </div>
                <div class="common_bg_heading">
                    <h2>Quickest disbursal</h2>
                </div>
            </div>
            <div class="box-bg">
                <div class="box-img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/Secure.webp" alt="">
                </div>
                <div class="common_bg_heading">
                    <h2>Safe and secure</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ================================================
        Approval Section End
=====================================================-->

    <!-- ================================================
            Loan Option Section Start
=====================================================-->
<section class="loan_option_section">
    <div class="loan_option_main" id="tabs">
        <div class="loan_option_left">
            <div class="txt_box common_sub_heading">
                <h3 class="left_spacing_heading">Loan Option</h3>

                <ul class="loan_accordion">
                    <li class="accordion-list active" data-index="0">
                        <span class="ui_span" href="#tab1">
                        <div class="Simplify_left">
                            <div class="terms_heading common_bold_heading">Term Loan</div>
                            <div class="active">
                            <div class="get_heading">Get a term loan up to ₹10 Lakh</div>
                            <div class="loan_option_step common_sub_heading">
                                    <h3>One-time capital injection</h3>
                                    <h3>Predictable monthly repayment</h3>
                                    <h3>Collateral Free</h3>
                            </div>
							<div class="loan_btn">
                            <a class="common_btn" href="<?php echo get_site_url(); ?>/term-loan/">Apply Now</a>
								</div>
							</div>
                        </div>
                    </span>
                    </li>

                    <li class="accordion-list" data-index="1">
                        <span class="ui_span" href="#tab2">
                        <div class="Simplify_left">
                            <div class="terms_heading common_bold_heading">Overdraft</div>
                            <div class="active">
                            <div class="get_heading">Access overdraft up to ₹10 Lakh</div>
                            <div class="loan_option_step common_sub_heading">
                                <div>
                                    <h3>Expanded credit line</h3>
                                </div>
                                <div>
                                    <h3>On-demand funds</h3>
                                </div>
                                <div>
                                    <h3>Collateral Free</h3>
                                </div>
                            </div>
							<div class="loan_btn">
                            <a class="common_btn" href="<?php echo get_site_url(); ?>/overdraft/">Apply Now</a>
								</div>
								</div>
                            </div>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
        <div class="loan_option_right">
            <div class="" id="tab1">
            <img src="<?php echo get_template_directory_uri(); ?>/images/loan_option.webp" alt="">
        </div>
        <div class="hide" id="tab2">
            <img src="<?php echo get_template_directory_uri(); ?>/images/loan_option1.webp" alt="">
        </div>
        </div>
    </div>
</section>

<!-- ================================================
        Loan Option Section Start
=====================================================-->

    <!-- ================================================
            Business Ambition Section Start
=====================================================-->
<section class="business_section">
    <div class="container">
        <div class="common_heading">Give wings to your business ambitions</div>
        <div class="common_sub_heading  top_content">
            <h3>Access easy 29-minute credit for your business, big or small</h3>
        </div>

        <div class="row business_slider">
            <div class="col-xl-3">
                <div class="business_box common_content text-center">
                    <div class="business_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/udyam.png" alt="">
                    </div>
                    <p>
                        Udyam registered MSMEs
                    </p>
                </div>
            </div>

            <div class="col-xl-3">
                <div class="business_box common_content text-center">
                    <div class="business_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/msme.png" alt="">
                    </div>
                    <p>
                        New to credit MSMEs
                    </p>
                </div>
            </div>

            <div class="col-xl-3">
                <div class="business_box common_content text-center">
                    <div class="business_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/sole.png" alt="">
                    </div>
                    <p>
                        Sole proprietors
                    </p>
                </div>
            </div>

            <div class="col-xl-3">
                <div class="business_box common_content text-center">
                    <div class="business_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/vintage.png" alt="">
                    </div>
                    <p>
                        Business vintage of 12 months
                    </p>
                </div>
            </div>

            <div class="col-xl-3">
                <div class="business_box common_content text-center">
                    <div class="business_img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/udyam.png" alt="">
                    </div>
                    <p>
                        Udyam registered MSMEs 5
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ================================================
        Business Ambition Section End
=====================================================-->

   <!-- ================================================
            Quicker Section Start
=====================================================-->
<section class="quicker_section">
    <div class="container">
        <div class="common_sub_heading">
            <h3>Why MoneyLo</h3>
        </div>
        <div class="common_heading  top_content">Quicker, Smarter, Simpler — The MoneyLo Advantage</div>
    </div>

    <div class="custom_wrapper">
        <div class="quicker_main quicker_slider">
            <div class="quicker_box common_content">
                <div class="credit_small_box">1</div>
                <div class="quicker_heading">Fastest and easiest loan application process</div>
                <p>Get your loan disbursed in under 29 minutes — quicker than ever.</p>
            </div>

            <div class="quicker_box common_content">
                <div class="credit_small_box">2</div>
                <div class="quicker_heading">Save money and gain flexibility</div>
                <p>Our competitive rates and flexible terms are designed to be cost-effective</p>
            </div>

            <div class="quicker_box common_content">
                <div class="credit_small_box">3</div>
                <div class="quicker_heading">Transparent loan options with no hidden fees</div>
                <p>Know exactly what you're paying — no surprises, just clear loan options.</p>
            </div>

            <div class="quicker_box common_content">
                <div class="credit_small_box">4</div>
                <div class="quicker_heading">Safe, secure and fully compliant</div>
                <p>The highest standards of security and compliance let you borrow with confidence.</p>
            </div>

            <div class="quicker_box common_content">
                <div class="credit_small_box">5</div>
                <div class="quicker_heading">Commitment to education and responsible lending</div>
                <p>Empower yourself financially by learning to borrow responsibly.</p>
            </div>

            <div class="quicker_box common_content">
                <div class="credit_small_box">6</div>
                <div class="quicker_heading">24x7 customer support</div>
                <p>From loan application to repayment — we're here to guide you, anytime.</p>
            </div>
        </div>

        <ul class="slider_ul">
            <li class="sprev-arrow slick-arrow" style="">
                <svg xmlns="http://www.w3.org/2000/svg" width="61" height="16" viewBox="0 0 61 16" fill="none">
                    <path
                        d="M0.292892 7.29289C-0.0976333 7.68341 -0.0976334 8.31658 0.292892 8.7071L6.65685 15.0711C7.04738 15.4616 7.68054 15.4616 8.07107 15.0711C8.46159 14.6805 8.46159 14.0474 8.07107 13.6569L2.41421 8L8.07107 2.34314C8.46159 1.95262 8.46159 1.31945 8.07107 0.92893C7.68054 0.538405 7.04738 0.538405 6.65685 0.92893L0.292892 7.29289ZM61 7L1 7L1 9L61 9L61 7Z"
                        fill="#605EBC" />
                </svg>
            </li>
            <li class="snext-arrow slick-arrow" style="">
                <svg xmlns="http://www.w3.org/2000/svg" width="61" height="16" viewBox="0 0 61 16" fill="none">
                    <path
                        d="M60.7071 7.29289C61.0976 7.68341 61.0976 8.31658 60.7071 8.7071L54.3431 15.0711C53.9526 15.4616 53.3195 15.4616 52.9289 15.0711C52.5384 14.6805 52.5384 14.0474 52.9289 13.6569L58.5858 8L52.9289 2.34314C52.5384 1.95262 52.5384 1.31945 52.9289 0.92893C53.3195 0.538405 53.9526 0.538405 54.3431 0.92893L60.7071 7.29289ZM-4.37114e-08 7L60 7L60 9L4.37114e-08 9L-4.37114e-08 7Z"
                        fill="#605EBC" />
                </svg>
            </li>
        </ul>
    </div>
</section>
<!-- ================================================
        Quicker Section End
=====================================================-->

    <!-- ================================================
            Testimonial Section Start
=====================================================-->
<section class="testimonial_section">
    <div class="container">
        <div class="common_sub_heading">
            <h3>TESTIMONIALS</h3>
        </div>
        <div class="common_heading top_content">What our customers say</div>


        <div class="testimonial_main">

            <div class=" grid-padding-x align-center">

                <div class="cell quotes_div">
                    <div class="quotes"></div>
                    <div class=" slider-for">
                        <div class="sin-testiText common_content">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Risus vel lobortis tincidunt
                                fames quisque mauris at diam. Nullam morbi ipsum turpis amet id posuere torto
                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore.</p>
                        </div>
                        <div class="sin-testiText common_content">
                            <p>Nam nec tellus a odio tincidunt This lorem is Photoshop's version of Lorem Ipsum.
                                Proin gravida nibh vel velit auctor aliquet. Aenean nisi sollicitudin,
                                lorem quis bibendum auctor, nisi elit consequat ipsum gravida.Proin gravida nibh vel
                                velit auctor aliquet.</p>
                        </div>
                        <div class="sin-testiText common_content">
                            <p>Nam nec tellus a odio tincidunt This is Photoshop's version of Lorem Ipsum.
                                Proin gravida nibh vel velit auctor aliquet. Aenean tincidunt sollicitudin,
                                lorem quis bibendum auctor, nisi elit consequat ipsum Photoshop.Proin gravida nibh
                                vel velit auctor aliquet.</p>
                        </div>
                        <div class="sin-testiText common_content">
                            <p>There are many variations of passages of Lorem Ipsum available,
                                but the majority have suffered alteration in some form, by injected humour,
                                or randomised words which don't look even slightly believable.but the majority have
                                suffered alteration in some form,</p>
                        </div>
                        <div class="sin-testiText common_content">
                            <p>Nam nec tellus a odio tincidunt This is Photoshop's version of Lorem Ipsum.
                                Proin gravida nibh vel velit auctor aliquet. Proin gravida nibh vel velit auctor
                                aliquet. Aenean sollicitudin,
                                aliquet lorem quis tellus velit bibendum auctor, nisi elit consequat ipsum</p>
                        </div>
                        <div class="sin-testiText common_content">
                            <p>Nam nec tellus a odio tincidunt This is Photoshop's
                                version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.
                                Aenean sollicitudin, lorem gravida tincidunt quis bibendum auctor, lorem gravida
                                tincidunt quis bibendum auctor, nisi elit consequat ipsum</p>
                        </div>
                    </div>
                </div>

                <div class="cell hello">
                    <div class="slider-nav">
                        <div class="sin-testiImage">
                            <div class="img_txt">
                                <img src="https://s26.postimg.cc/bz6kq188p/rew1.jpg" alt="">
                            </div>
                            <div class="customer_div common_content">
                                <div class="customer_name">customer 1</div>
                                <p>Manager of the company</p>
                            </div>
                        </div>
                        <div class="sin-testiImage">
                            <div class="img_txt">
                                <img src="https://s26.postimg.cc/cbxyw85y1/rew2.jpg">
                            </div>
                            <div class="customer_div common_content">
                                <div class="customer_name">customer 2</div>
                                <p>Manager of the company</p>
                            </div>
                        </div>
                        <div class="sin-testiImage">
                            <div class="img_txt">
                                <img src="https://s26.postimg.cc/rxfag6a6h/rew3.jpg">
                            </div>
                            <div class="customer_div common_content">
                                <div class="customer_name">customer 3</div>
                                <p>Manager of the company</p>
                            </div>
                        </div>
                        <div class="sin-testiImage">
                            <div class="img_txt">
                                <img src="https://s26.postimg.cc/bz6kq188p/rew1.jpg">
                            </div>
                            <div class="customer_div common_content">
                                <div class="customer_name">customer 4</div>
                                <p>Manager of the company</p>
                            </div>
                        </div>
                        <div class="sin-testiImage">
                            <div class="img_txt">
                                <img src="https://s26.postimg.cc/cbxyw85y1/rew2.jpg">
                            </div>
                            <div class="customer_div common_content">
                                <div class="customer_name">customer 5</div>
                                <p>Manager of the company</p>
                            </div>
                        </div>
                        <div class="sin-testiImage">
                            <div class="img_txt">
                                <img src="https://s26.postimg.cc/rxfag6a6h/rew3.jpg">
                            </div>
                            <div class="customer_div common_content">
                                <div class="customer_name">customer 6</div>
                                <p>Manager of the company</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<!-- ================================================
        Testimonial Section End
=====================================================-->



  <!-- ================================================
            Partners Section Start
=====================================================-->
<section class="partners_sectionc">
    <div class="container">
     <div class="common_sub_heading">
            <h3>AFFILIATED WITH</h3>
        </div>
    
        <div class="partners_div">
            <div class="logo">
                <div class="logo_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/patners/yesbank_img.png" alt="">
                </div>
            </div>
            <div class="logo">
            <div class="logo_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/patners/samhita_img.png" alt="">
                </div>
            </div>
            <div class="logo">
            <div class="logo_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/patners/cgtmse_img.png" alt="">
            </div>
            </div>
            <div class="logo">
            <div class="logo_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/patners/ugro_img.png" alt="">
                </div>
            </div>
        


    </div>
</section>
<!-- ================================================
        Partners Section End
=====================================================-->
<!-- ================================================
        Partners Section End
=====================================================-->

    <!-- ================================================
            About Money Section Start
=====================================================-->
<section class="about_money_section">
    <div class="container">
        <div class="common_sub_heading">
            <h3>About MoneyLo</h3>
        </div>
        <div class="common_heading top_content">Empowering smarter financial decisions
            by democratising access to credit</div>
    </div>
    <div class="about_main_div">
    <div class="about_main">
        <div class="about_left">
            <div class="about_logo">
                <div class="logo_img_about">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/about_logo.webp" alt="">
                </div>
            </div>
            <div class="loan_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/loan.webp" alt="">
            </div>
        </div>
        <div class="about_right">
            <div class="common_content">
                <p>
                    MoneyLo is a financial technology offering democratising access to clear, transparent, and affordable credit for millions of Indians – because we believe everyone deserves the opportunity to achieve their financial goals.

                </p>
                <p>
                   MoneyLo is powered by Appreciate – a leading fintech company on a mission to enable access to affordable finance.
                </p>
            </div>

            <div class="about_mission">Mission</div>
            <ul class="misson_step">
                <li>Speed up and simplify the loan application process</li>
                <li>Offer competitive rates and terms</li>
                <li>Educate borrowers about loan options</li>
                <li>Drive financial inclusion for new-to-credit borrowers</li>
                <li>Foster financial wellness through responsible lending practices</li>
                <li>Help infromal micro enterprises get registered with the government</li>
            </ul>

            <div class="common_content">
                <p>
                    MoneyLo is powered by <span>Appreciate</span>
                </p>
                <p>
                    A leading fin-tech company on a mission to democratise finance.
                </p>
            </div>
        </div>
    </div>
    </div>
</section>
<!-- ================================================
        About MOney Section End
=====================================================-->

<!-- ================================================
            FAQ Section Start
=====================================================-->
<section class="common_padding frequently_section">
    <div class="container">
        <div class="common_sub_heading top_content">
            <h3>Frequently Asked Questions</h3>
        </div>

        <div class="faq_accordion_main">
            <div class="faq_accordion">
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">What types of loans are available through MoneyLo?</p>
                    </button>
                    <div class="accordion-content answer">
                        <p>MoneyLo currently offers term loans to help MSMEs get instant access to funds and grow their businesses. We are also actively 
							working on expanding our offerings to include overdraft (OD) facilities and other types of loans in the near future.</p>
                    </div>
                </div>
              
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">Can I track the status of my loan application?</p>
                    </button>
                    <div class="accordion-content answer">
                        <p>Yes, MoneyLo offers a real-time tracking feature that allows you to monitor the status of your loan application. 
							You will receive timely updates on each stage of the process.</p>
                    </div>
                </div>
               
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">Is my personal and business information secure on MoneyLo?</p>
                    </button>
                    <div class="accordion-content answer">
                        <p>Yes, we prioritize the security and confidentiality of your data. The MoneyLo app uses strong encryption and security measures to protect your information.</p>
                    </div>
                </div>

                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title"> How long does it take to get the loan disbursed? </p>
                    </button>
                    <div class="accordion-content answer">
                        <p>The turnaround time (TAT) for disbursing the loan is typically 5 working days after submission.</p>
                    </div>
                </div>
                
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">What happens if a customer misses their loan payment? </p>
                    </button>
                    <div class="accordion-content answer">
                        <p>If a customer misses a loan payment, it may affect their CIBIL score and result in additional penalties. 
							It's advisable to contact customer support to discuss potential solutions.</p>
                    </div>
                </div>
                
            </div>

            <div class="faq_accordion">
                
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">Why should I register with Udyam?</p>
                    </button>
                    <div class="accordion-content answer ">
                        <p>Udyam is a dedicated platform designed to streamline and support MSMEs in India. By registering with Udyam, 
							you gain access to a range of essential services and benefits that can help your business thrive.</p>
                    </div>
                </div>
               
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">Is stamping and signing done digitally during the registration process?</p>
                    </button>
                    <div class="accordion-content answer">
                        <p>Yes, MoneyLo facilitates a fully digital registration process. Stamping and signing of documents are done electronically, 
							ensuring a seamless and paperless experience for users.</p>
                    </div>
                </div>
               
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">What if I encounter issues during the loan application process?</p>
                    </button>
                    <div class="accordion-content answer">
                        <p>MoneyLo has a dedicated customer support channel to assist you with any queries or issues. Reach out to our support team through the help centre for prompt assistance.</p>
                    </div>
                </div>
                
                <div class="faq_accordion-item common_content">
                    <button>
                        <p class="accordion-title">What is the range between which customers can opt for a loan? </p>
                    </button>
                    <div class="accordion-content answer">
                        <p>Customers can opt for a loan amount ranging from 50,000 to 25,00,000 INR.</p>
                    </div>
                </div>
              
            </div>
        </div>
</section>
<!-- ================================================
        FAQ Section End
=====================================================-->
	<!-- ================================================
            Terms Condition Section End
=====================================================-->

<!-- ================================================
   Modal pop up section start
=====================================================-->

<div class="custom-model-main">
    <div class="custom-model-inner container">
         <div class="close-btn">×</div>
        <div class="row">
            <div class="col-xl-6">
                <div class="model_contact_details">
               <div class="common_heading">
               We would love to hear from you
               </div> 
               <div class="modal_custom_content">
               Have something nice or not so nice to say? Do you have any questions? Reach out to us, we’d love to start a dialogue with you.
               </div>
               <ul class="mail_list">
                <li class="mail_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/mail.svg" alt="">
                </li>
                <li class="mail_text"><a target="_blank" href="mailto:helpdesk@ppreciate.com">helpdesk@appreciate.com</a></li>
               </ul>
               <ul class="call_list">
                <li class="call_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/call.svg" alt="">
                </li>
                <li class="call_text"><a href="tel:+91-7039325849">+91 70393 25849</a><br><span>(9 am to 9 pm)</span></li>
               </ul>
               </div>
               <div class="model_left_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/contact_box.png" alt="">
               </div>
            </div>
            <div class="col-xl-6">
                <div class="modal_form">
                	 <?php echo do_shortcode('[contact-form-7 id="395c14b" title="Contact form"]');?>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-overlay"></div>
</div>  
<!-- ================================================
   Modal pop up section end
=====================================================-->


<?php get_footer();?>