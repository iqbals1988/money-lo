<?php

/*
Template Name: Privacy-Policy Page
*/

get_header();
?>

	<!-- ================================================
            Privacy-Policy Section Start
=====================================================-->
<section class="terms_condition_section privacy_policy">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-5 col-sm-12 privacy_left_div">
                <ul class="terms_list">
					   <li class="nav-item nav-1" value=1 onclick="handleListScroll(1)">Definitions and Interpretations
                        </li>
                    <li class="nav-item nav-2" value=2 onclick="handleListScroll(2)">Purpose</li>
                        <li class="nav-item nav-3" value=3 onclick="handleListScroll(3)">Information the Company
                            Collects
                        </li>

                        <li class="nav-item nav-4" value=4 onclick="handleListScroll(4)">Information Security
                        </li>
                        <li class="nav-item nav-5" value=5 onclick="handleListScroll(5)">Information the Company Shares
                        </li>
                        <li class="nav-item nav-6" value=6 onclick="handleListScroll(6)">Change in Privacy Policy
                        </li>

                        <li class="nav-item nav-7" value=7 onclick="handleListScroll(7)">Choice/Opt-Out</li>
                        <li class="nav-item nav-8" value=8 onclick="handleListScroll(8)">Severability</li>
                        <li class="nav-item nav-9" value=9 onclick="handleListScroll(9)">Waiver</li>

                        <li class="nav-item nav-10" value=10 onclick="handleListScroll(10)">Governing law and
                            Jurisdiction
                        </li>
                        <li class="nav-item nav-11 " value=11 onclick="handleListScroll(11)">Questions and Grievances
                        </li>
                </ul>
            </div>
            <div class="col-xl-8 col-lg-7 col-sm-12 ">
                <div  class="scrollToTopBtn">
                <div class="common_heading">Privacy Policy</div>
                <div class="terms_content common_content privacy_description">
                    <p>
                    This privacy policy (“Privacy Policy”) has been drafted and published in accordance with the Information Technology Act, 2000 and the InformationTechnology (Reasonable security practices and procedures and sensitive personal data or information) Rules, 2011.
                    </p>
                    <p>Appreciate Credit Technologies Private Limited or MoneyLo (“Company”) is concerned about the privacy of the users (hereinafter referred to as “You”, “Your” or “User”) of its website located at www.MoneyLo.com(“Website”) and MoneyLo mobile application available on Apple AppStore and Google Play Store (“App”). Where the context so requires, the Website and the App shall be collectively referred to as the“Platform”.This Privacy Policy describes the Company’s policies and procedures for collection, use, storage, processing, disclosure and protection of any information,including, but not limited to, business or personal information provided by You while using the Platform.
</p>
     <p>This policy constitutes a legal agreement between You, as the user of the Platform,and the Company, as the owner of the Platform. You must be a natural person who is at least 18 (eighteen) years of age. If You are less than 18 (eighteen) years of age, please read through this Privacy Policy with Your parent or legal guardian, and in such a case this Privacy Policy shall be deemed to be a contract between theCompany and Your legal guardian or parent and to the extent permissible underApplicable Laws, enforceable against You.
</p>
    <p>By availing the Services, visiting or accessing the Platform and voluntarily providing the Company with information (personal and/ or non- personal), You are consenting to the Company’s use of it in accordance with this Privacy Policy. This Privacy Policy does not apply to third-party websites/ applications that are connected via links to the Platform. If You do not agree with the terms and conditions of this Privacy Policy,please do not proceed further to use and access this Platform.
</p>
 <p>Your use of the Platform will be governed by this Privacy Policy as applicable to thePlatform together with all policies, notices, guidelines, disclaimers that are published and shared with You from time to time which are incorporated herein byway of reference including but not limited to Terms and Conditions and such other terms as may be applicable to You in Your capacity as a user of the Platform. ThisPrivacy Policy shall be enforceable against You in the same manner as any other written agreement.</p>
                    <p>The Company may update this Privacy Policy from time to time. You must periodically review the Privacy Policy for the latest information on the Company's Privacy practices.</p>
                </div>
            <div class="pp_accordion_blog_details">
                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3 id="section1"  >Definitions and Interpretations
                    <span class="t-c-btn"></span>
                    </h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>“Applicable Law” means all laws, ordinance, statutes, rules, orders, decrees, injunctions, licenses, permits, approvals, authorizations, consents, waivers, privileges, agreements and regulations of any governmental authority/court of law having jurisdiction over the relevant matter including any interpretations thereof, in effect.
</p>    
                    <p>“Cookies” means small files that reside on Your computer or other mobile devices hard drive and generally contain an anonymous unique identifier and are accessible only by the website/ application that placed them there and not any other sites.
</p>
                    <p>“Force Majeure Event” means any event that is beyond the Company's Reasonable control and shall include, without limitation, sabotage, fire, flood,explosion, acts of God, civil commotion, strikes or industrial action of any kind, riots,insurrection, war, acts of government, computer hacking, unauthorised access to computer, computer system or computer network, computer crashes, breach of security and encryption (provided beyond the Company’s reasonable control),power or electricity failure or unavailability of adequate power or electricity.
</p>
                    <p>“Services” means and includes provision of investment advice, and facilitation of investments on Company’s Platform, as well as all ancillary activities performed to support the provision of investment advice and the facilitation of investments on the Platform.
</p>
                    <p>“Terms and Conditions” means the terms and conditions available on thePlatform.</p>
                    <p>“User Account” means the personal online account created by User to gain accessand use the Platform.</p>    
                </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section2">Purpose <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>The purpose of this Privacy Policy is to ensure that the Your information provided by You is used, processed, disclosed and stored in accordance with the Applicable Laws. The information stored in such manner shall be protected by the Company in accordance with the terms and conditions set out in this Privacy Policy. Company’s Privacy Policy explains:</p>    
                    <ol class="common_content inner_list_number">
                        <li><p>What information is collected and why such information is collected;</p></li>
                        <li><p>How such information is used; and</p></li>
                        <li><p>How such information can be accessed and updated.</p></li>
                    </ol>
                    <p>Please read the following Privacy Policy to learn about the Company’s information gathering and dissemination practices</p>
                </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section3">Information the Company Collects <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>During Your use of the Platform and with respect to the Company’s Services availed by you, the Company may collect and process such information from You, including but not limited to the information mentioned below:</p>
                    <p>A.Personal Information: This includes the information that can be used to uniquely identify or contact You (“Personal Information”). While you create the User Account on the Platform and avail the Company’s Services through the Platform, the Company may collect a variety of Personal Information, including but not limited to, Your name, postal address, phone number, email address, contact preferences, etc.</p>    
                    <p>You are required to ensure that Your contact information and preferences are accurate, complete and up to date by logging into the User Account. The Company shall also provide You with the opportunity to request correction of data relating to Your Personal Information if the same is inaccurate or delete the data. Further, the Company may decline to process requests which the Company finds to be contrary to the terms laid down under this Privacy Policy, the Terms and Conditions or any Applicable Laws, or which require disproportionate technical effort, jeopardize the privacy of others or are extremely impractical.</p>
                    <p>In the event You make payments on the Platform via a payment gateway to complete any transaction on the Platform, the Company may collect and store Your credit, debit card and other financial information in accordance with Applicable Law. You acknowledge that the payment gateway may be provided by a third party service provider, in which case applicable terms and use and privacy policy of such service provider shall be applicable.</p>
                    <p>The Personal Information is collected from You in a voluntary fashion when You provide your credentials on the Platform. You may choose to not provide such Personal Information to the Company.</p>
                    <p>B. Non-Personal Information: Non-personal information is any information that does not reveal Your specific identity, such as, browser information, information collected through, pixel tags and other technologies, demographic information, etc., (“Non-Personal Information”). As is true with most websites and applications, the Company’s Platform gathers some information automatically when You visit the Platform and stores it in log files. When You use the Platform, the Company may collect certain information about Your computer to facilitate, evaluate and verify Your use of the Platform. For example, the Company may store environmental variables, such as browser type, operating system, speed of the central processing unit (CPU), referring or exit web pages, click patterns and the internet protocol (IP) address of Your computer. This information is generally collected in aggregate form, without identifying any user individually.</p>
                    <p>The Website may use also temporary Cookies to help you access some of the special functions within the database driven areas of the Website. Once you leave the Website, these Cookies expire.</p>
                    <p>We, or third parties authorised by the Company, may use the information provided by You in the following ways, viz:</p>
                    <p>To create User Account and to support You with any services related to Your User Account;</p>
                    <ul class="unordered_list_terms">
                        <li>
                            <p>To Provide You the Services through the Platform;</p>
                        </li>
                        <li>
                            <p>To update you upon the development and news with respect to Services or any other products or related services of the Company;</p>
                        </li>
                        <li>
                            <p>To collect any monies owed by You to the Company;</p>
                        </li>
                        <li>
                            <p>Conduct research and analysis to detect, prevent, mitigate and investigate fraudulent or illegal activities;</p>
                        </li>
                        <li>
                            <p>Analyze how the Platform is used, diagnose service or technical problems, maintain security;</p>
                        </li>
                        <li>
                            <p>To help You efficiently access the Platform and avail the Services;</p>
                        </li>
                        <li>
                            <p>Monitor aggregate metrics such as total number of users, traffic, and demographic patterns;</p>
                        </li>
                        <li>
                            <p>To notify You regarding your User Account, to troubleshoot problems with Your User Account, to resolve a dispute, to confirm Your identity in order to ensure that You are eligible to use the Platform;</p>
                        </li>
                        <li>
                            <p>For advertising and marketing communications. The Company may also share Non-Personal Information with third parties such as, the Company’s advertisers, sponsors, investors, business partners;</p>
                        </li>
                        <li>
                            <p>To carry out the Company’s obligations and to process transactions arising from any contracts entered into between You and the Company;</p>
                        </li>
                        <li>
                            <p>To notify You about changes on the Platform;</p>
                        </li>
                        <li>
                            <p>Notify You, if possible, in the event The Company becomes aware of any breach of the security of Your information and take appropriate action to the best of the Company’s ability to remedy such a breach;</p>
                        </li>
                        <li>
                            <p>To enable the Company to comply with legal and regulatory obligations;</p>
                        </li>
                        <li>
                            <p>
                            To act on your behalf as a power of attorney holder, where you authorize us to do so;
                            </p>
                        </li>
                        <li>
                            <p>To carry out operation of bank accounts (including but not limited to managing remittances, dong credit assessment) exclusively associated with the making investments or facilitating credit supported by the Company, where you authorize us to do so;</p>
                        </li>
                    </ul>
                <p>The Company will use and retain Your information for such periods as necessary to comply with the Company’s legal obligations, resolve disputes, and enforce the Company’s agreements.</p>
                </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section4">Information Security <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <ol class="common_content inner_list_number">
                      <li>
                        <p>The Company uses reasonable safeguards to protect and preserve the integrity and security of Your information against unauthorized access, loss, theft, unauthorised, reproduction, use or amendment, disclosure or destruction of information the Company holds. The Company encrypts its Services using secure server software, which is the industry standard and among the best software available today for secure transactions. The Company uses reasonable security practices and procedures and use secure servers as mandated under Applicable Laws for the protection of Your information. The Company reviews its information collection, storage and processing practices, including physical security measures to guard against unauthorized access to systems.</p>
                      </li>
                      <li>
                        <p>The Company limits the disclosure of Personal Information to its employees, independent contractors including vendors, affiliates, consultants, business associates, service providers and distributors of the Services, on a “need-to-know” basis, and only if the disclosure will enable that entity to provide the Company with business, professional, or technical support or fulfill Your request. However, the Company is not responsible for any breach of security or for any actions of any third parties that receive Your Personal Information. The Company shall not be liable for any loss or injury caused to You as a result of You providing Your Personal Information to third party (including any third party websites) even if links to such third party websites are provided on the Platform.</p>
                      </li>
                      <li>
                        <p>As a registered user with a User Account, You are responsible for keeping Your password confidential. By submitting Your information on the Platform, You agree to the handling of Your information by the Company in a manner as stated under this Privacy Policy. The Company will take such steps as it considers reasonably necessary to ensure that Your information is treated securely and in accordance with the Privacy Policy.</p>
                      </li>
                      <li>
                        <p>By using the Platform, You accept the inherent security implications of data transmission over the internet and the world wide web cannot always be guaranteed as completely secure. Therefore, Your use of the Platform will be at Your own risk.</p>
                      </li>
                      <li>
                        <p>Notwithstanding anything contained in this Privacy Policy or elsewhere, the Company shall not be held responsible for any loss, damage or misuse of Your Personal Information, if such loss, damage or misuse is attributable to a Force Majeure Event.</p>
                      </li>
                      <li>
                        <p>You agree and acknowledge that the Company shall retain all information provided by You until such time as is required by the Applicable Law or until it is required for the Company’s internal use, whichever is later.</p>
                      </li>
                    </ol>
                    </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section5">Information the Company Shares <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <ol class="common_content inner_list_number">
                     <li>
                        <p>The Company may disclose any information provided by You on the Platform as may be deemed to be necessary or appropriate: (a) under Applicable Law, including laws outside Your country of residence; (b) to comply with legal process; (c) to respond to requests from public and government authorities including public and government authorities outside Your country of residence; (d) to enforce Terms and Conditions; (e) to protect the Company’s operations or those of any of its affiliates; (f) to protect the Company’s rights, privacy, safety or property, and/or that of its affiliates, You or others; and (g) to allow the Company to pursue available remedies or limit the damages that the Company may sustain.</p>
                     </li>
                     <li>
                        <p>The Company may share Personal Information with other corporate entities and affiliates to help detect and prevent identity theft, fraud and other potentially illegal acts and to prevent abuse of the Platform or Services. The Company may disclose Personal Information to the Company’s third party providers including but not limited to those who provide products or services such as contact information verification, payment processing, Platform hosting, data analysis, infrastructure provision, IT services, auditing services and other similar services. In such an event, the third parties’ use of Your information will be bound, among other things, by confidentiality obligation and the Privacy Policy. The Company may store information in locations outside the direct control of the Company (for instance, on servers or databases co-located with hosting providers).</p>
                     </li>
                     <li>
                        <p>The Company may be involved in the transaction of a merger, acquisition, sale of assets, business re-organization, bankruptcy etc. During such a process, it may sell, transfer or otherwise share some or all of its assets which may include Your information. However, in such an event of sale or transfer, the Company shall reasonably ensure that Your information collected and stored by the Company is stored and used by the transferee in a manner that is consistent with this Privacy Policy. Any such third party to whom the Company transfers or sells shall have the right to continue to use the information that You provide to the Company or collected by the Company immediately prior to such transfer or sale. On completion of the sale or transfer, the Privacy Policy of the third party shall apply with respect to Your information. To stay updated about such business transactions, please read this Policy from time to time.</p>
                     </li>
                     <li>
                        <p>The Company assumes no liability for any disclosure of information due to errors in transmission, unauthorised third party access or other acts of third parties, or acts or omissions beyond the Company’s reasonable control and You agree that You will not hold the Company responsible for any breach of security unless such breach has been caused as a direct result of the Company’s gross negligence or wilful default. The Company may also collect Personal Information and information about your transactions with the Company and those You engage in with the Company’s affiliates, unaffiliated third parties, banking verification services and information from consumer reporting agencies. The Company may further collect information about You from third-party data sources, such as brokers, banks and government databases. The Company may combine data the Company collects about You from third-party data sources with data the Company collects from You and may use and share such data as described in this Privacy Policy.</p>
                     </li>
                    </ol>
                </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section6">Change in Privacy Policy <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                        <p>The Company may update this Privacy Policy at any time, with or without advance notice. In the event there are significant changes in the way the Company treats Your Personal Information, Company will display a notice on the Platform or send You an email, as provided for above. Unless stated otherwise, this Privacy Policy applies to all information that Company has about You and Your User Account. Notwithstanding the above, Company shall not be required to notify You of any changes made to the Privacy Policy. If You use the Platform after notice of changes have been sent to You or published on the Platform, You hereby provides Your consent to the changed practices.</p>   
                        <ol class="common_content inner_list_number">
                     <li>
                        <p>Company provides all its Users with the opportunity to opt-out of receiving non-essential communications from the Company or on behalf of the Company’s partners after setting up a User Account.</p>                     
                     </li>
                    <li>
                        <p>If You want to remove Your contact information from the Company’s lists and newsletters, please write to the Company at unsubscribe@ppreciate.com with “unsubscribe” as the subject.</p>
                    </li>
                    </ol>
                    </div>  
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section7">Choice/Opt-Out <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                        <ol class="common_content inner_list_number">
                     <li>
                        <p>Company provides all its Users with the opportunity to opt-out of receiving non-essential communications from the Company or on behalf of the Company’s partners after setting up a User Account.</p>
                     </li>
                    <li>
                        <p>If You want to remove Your contact information from the Company’s lists and newsletters, please write to the Company at unsubscribe@ppreciate.com with “unsubscribe” as the subject.</p>
                    </li>
                    </ol>
                    </div>  
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section8">Severability <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                       <p>The Company has taken every effort to ensure that this Privacy Policy adheres with the Applicable Laws. The invalidity or unenforceability of any part of this Policy shall not prejudice or affect the validity or enforceability of the remainder of this Privacy Policy. This Privacy Policy does not apply to any information other than the information collected by the Company through the Platform. This Privacy Policy shall be inapplicable to any unsolicited information You provide the Company through this Platform or through any other means. This includes, but is not limited to, information posted in any public areas of the Platform. All unsolicited information shall be deemed to be non-confidential and the Company shall be free to use and/ or disclose such unsolicited information without any limitations.</p>
                    </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section9">Waiver <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                        <p>Any rights or remedies under this Privacy Policies may be waived only in writing. Delay in exercising or non-exercise of any such right or remedy does not constitute a waiver of that right or remedy, or any other right or remedy.</p>                    
                    </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section10">Governing law and Jurisdiction <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>This Privacy Policy is governed by and construed in accordance with the laws of India. Any dispute arising out of or in connection with the use of the Platform or this Privacy Policy shall be subject to the exclusive jurisdiction of the courts in Mumbai, India.</p>
                    </div>
					</div></div>
               
                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section11">Questions and Grievances <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>Your grievances, questions or feedback regarding this Privacy Policy should be directed to the Company’s grievance officer mentioned below:</p>
                        <ul class="unordered_list_terms">
                            <li>
                                <p><b>Name:</b> Shlok Srivastav</p>
                            </li>
                            <li>
                                <p><b>Email Id:</b> <a href="#!">concerns@ppreciate.com</a></p>
                            </li>
							<li>
								<p>
									<b>Address:</b> Floor-2, 0-14, Mahalaxmi Industrial Estate, Dainik Shivneri Marg, Worli, Mumbai City, Maharashtra, 400018
								</p>
							</li>
                        </ul>
						</div></div>
                </div>
                </div>
                </div>
        </div>
    </div>
		</div></section>
	<!-- ================================================
           Privacy-Policy Section End
=====================================================-->

<!-- ================================================
   Modal pop up section start
=====================================================-->

<div class="custom-model-main">
    <div class="custom-model-inner container">
         <div class="close-btn">×</div>
        <div class="row">
            <div class="col-xl-6">
                <div class="model_contact_details">
               <div class="common_heading">
               We would love to hear from you
               </div> 
               <div class="modal_custom_content">
               Have something nice or not so nice to say? Do you have any questions? Reach out to us, we’d love to start a dialogue with you.
               </div>
               <ul class="mail_list">
                <li class="mail_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/mail.svg" alt="">
                </li>
                    <li class="mail_text"><a target="_blank" href="mailto:helpdesk@ppreciate.com">helpdesk@appreciate.com</a></li>
               </ul>
               <ul class="call_list">
                <li class="call_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/call.svg" alt="">
                </li>
                <li class="call_text"><a href="tel:+91-7039325849">+91 70393 25849</a><br><span>(9 am to 9 pm)</span></li>
               </ul>
               </div>
               <div class="model_left_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/contact_box.png" alt="">
               </div>
            </div>
            <div class="col-xl-6">
                <div class="modal_form">
                	 <?php echo do_shortcode('[contact-form-7 id="395c14b" title="Contact form"]');?>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-overlay"></div>
</div>  
<!-- ================================================
   Modal pop up section end
=====================================================-->


<?php get_footer();?>



<?php get_footer();?>