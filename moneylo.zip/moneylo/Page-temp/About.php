<?php

/*
Template Name: About Us Page
*/

get_header();
?>

	<!-- ================================================
            About Banner Section Start
=====================================================-->
<div class="about_banner_section">
      
        
      <div class="about_banner_main">
          <div class="about_banner_div">
              <img src="<?php echo get_template_directory_uri(); ?>/images/aboutusbanner.webp" alt="">
              <div class="container">
                  <div class="about_banner_center">
                    <h1 class="banner_heading banner_conent">
                      On a journey to be the #1 trusted destination for you to achieve your financial goals     
                    </h1>
                  </div>
              </div>
          </div>


</div>
<!-- ================================================
         About Banner Section End
=====================================================-->

<!-- ================================================
         Our Valur Section start
=====================================================-->
<section class="our_value_section">
    <div class="container">
    <div class="common_heading">Our Values and Principles</div>
        <div class="top_content">
            <div class="ourvalue_sub_heading">If these values resonate with you, send us your resume along with a short cover letter to talent@ppreciate.com</div>
        </div>

        <div class="row">
        <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="our_value_box common_content">
                <div class="our_value_heading">Customers first always</div>
                <p>We are customer obsessed, customer inspired, customer driven - if it does not make sense for our customers, we do not do it.</p>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="our_value_box common_content">
                <div class="our_value_heading">Integrity and Safety are non-negotiable</div>
                <p>Integrity (in all its forms - legal, moral, corporate, personal) and safety are cornerstones for us. These values are more important than growth or profits.</p>
                </div>
            </div>
           
            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="our_value_box common_content">
                <div class="our_value_heading">Meritocracy of people and ideas</div>
                <p>The best ideas win, the best people rise to the top. No hierarchy or nepotism, Zero tolerance for discrimination..</p>
                </div>
            </div>

            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="our_value_box common_content">
                <div class="our_value_heading">Action oriented owner-doers</div>
                <p>We rise to challenges and solve problems without giving up or passing the buck. We have an owner's mindset and an entrepreneurial spirit.</p>
                </div>
            </div>

            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="our_value_box common_content">
                <div class="our_value_heading">We build the ecosystem</div>
                <p>We are building a destination for consumers, partners, and intermediaries. We ensure that our ecosystem works for everyone by being flexible and thoughtful.</p>
                </div>
            </div>

            <div class="col-xl-4 col-lg-4 col-sm-6">
                <div class="our_value_box common_content">
					<div class="our_value_heading">Obligation to </br> dissent</div>
                <p>We speak up when something is wrong. Each one of us has an obligation to dissent if we disagree with any decision or actions our teams, peers or managers are taking.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ================================================
         Our Valur Section End
=====================================================-->

<!-- ================================================
         Board and Management Section Start
=====================================================-->
<section class="board_section">
    <div class="container">
    <div class="common_heading top_content">Board and Management</div>
    
    <div class="row">
        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/about_person.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Subho Moulik</div>
                <p>CEO</p>
            </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Shlok.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Shlok Srivastav</div>
                <p>COO</p>
            </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Yogesh.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Yogesh Kansal</div>
                <p>COO</p>
            </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Ayush.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Ayush Kumar</div>
                <p>Head of Marketing</p>
            </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Neeraj.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Neeraj Ganjoo</div>
                <p>Head of Partnerships & Alliances</p>
            </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Nidhi.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Nidhi Jaswal</div>
                <p>Head of Product</p>
            </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Hemant.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Hemant Chhonkar</div>
                <p>VP Engineering</p>
            </div>
            </div>
        </div>
        
    </div>



<div class="advisor_div common_content">
    <div class="common_heading">Our Advisors</div>
    <p>Our advisors have global standing in the financial services industry and together have more than 150 years of experience in financial services and technology.  They work with the founding team on a weekly basis to ensure that we provide our customers the best outcomes in the most safe and secure manner.</p>
    
    <div class="row">
        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Sunil.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Sunil Srivastav</div>
                <p>Former DMD at SBI</p>
            </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Ram.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Ram Rastogi</div>
                <p>Former Head of Product at NPCI</p>
            </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Sandip.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Sandip Ghose</div>
                <p>Former Director NISM at RBI</p>
            </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Dipti.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Dipti Neelakantan</div>
                <p>Former Group COO at JM Financial</p>
            </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-4 col-sm-4">
            <div class="board_box">
            <div class="board_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/person/Jose.png" alt="">
            </div>
            <div class="customer_div common_content">
                <div class="customer_name">Jose Sebastian</div>
                <p>CIO at Rialto</p>
            </div>
            </div>
        </div>

   
        </div>
    </div>
</section>

<!-- ================================================
         Board and Management Section End
=====================================================-->

   <!-- ================================================
            Partners Section Start
=====================================================-->
<section class="partners_section about_patner_sec">
    <div class="container">
    <div class="common_heading top_content">Who we work with</div>
    
         <div class="partners_div">
            <div class="logo">
                <div class="logo_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/patners/yesbank_img.png" alt="">
                </div>
            </div>
            <div class="logo">
            <div class="logo_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/patners/samhita_img.png" alt="">
                </div>
            </div>
            <div class="logo">
            <div class="logo_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/patners/cgtmse_img.png" alt="">
            </div>
            </div>
            <div class="logo">
            <div class="logo_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/patners/ugro_img.png" alt="">
                </div>
            </div>
        


    </div>
</section>
<!-- ================================================
        Partners Section End
=====================================================-->

   <!-- ================================================
            Join growing tribe Section Start
=====================================================-->
<section class="join_tribe_section">
    <div class="container">
    <div class="common_heading top_content">Join the growing tribe of 2,00,000+ Appreciators</div>

    <div class="google_app_btn">
                <a href="#" class="Googleplaystore">
                <img src="<?php echo get_template_directory_uri(); ?>/images/Googleplaystore.webp" alt="">
                </a>
                <a href="#" class="app_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/AppStore.webp" alt="">
                </a>
            </div>
</section>
   <!-- ================================================
            Join growing tribe Section End
=====================================================-->
	<!-- ================================================
            Terms Condition Section End
=====================================================-->

<!-- ================================================
   Modal pop up section start
=====================================================-->

<div class="custom-model-main">
    <div class="custom-model-inner container">
         <div class="close-btn">×</div>
        <div class="row">
            <div class="col-xl-6">
                <div class="model_contact_details">
               <div class="common_heading">
               We would love to hear from you
               </div> 
               <div class="modal_custom_content">
               Have something nice or not so nice to say? Do you have any questions? Reach out to us, we’d love to start a dialogue with you.
               </div>
               <ul class="mail_list">
                <li class="mail_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/mail.svg" alt="">
                </li>
                    <li class="mail_text"><a target="_blank" href="mailto:helpdesk@ppreciate.com">helpdesk@appreciate.com</a></li>
               </ul>
               <ul class="call_list">
                <li class="call_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/call.svg" alt="">
                </li>
                <li class="call_text"><a href="tel:+91-7039325849">+91 70393 25849</a><br><span>(9 am to 9 pm)</span></li>
               </ul>
               </div>
               <div class="model_left_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/contact_box.png" alt="">
               </div>
            </div>
            <div class="col-xl-6">
                <div class="modal_form">
                	 <?php echo do_shortcode('[contact-form-7 id="395c14b" title="Contact form"]');?>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-overlay"></div>
</div>  
<!-- ================================================
   Modal pop up section end
=====================================================-->


<?php get_footer();?>