<?php

/*
Template Name: Terms and condition copy Page
*/

get_header();
?>

	<!-- ================================================
            Terms and condition Start
=====================================================-->
<section class="terms_condition_section privacy_policy">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-5 col-sm-12 privacy_left_div">
                <ul class="terms_list">
					   <li class="nav-item nav-1" value=1 onclick="handleListScroll(1)">Eligiblity
                        </li>
                    <li class="nav-item nav-2" value=2 onclick="handleListScroll(2)">Description of Services</li>
                        <li class="nav-item nav-3" value=3 onclick="handleListScroll(3)">Acceptance of Terms
                        </li>

                        <li class="nav-item nav-4" value=4 onclick="handleListScroll(4)">License to Use
                        </li>
                        <li class="nav-item nav-5" value=5 onclick="handleListScroll(5)">User Account
                        </li>
                        <li class="nav-item nav-6" value=6 onclick="handleListScroll(6)">Limitation of Liability
                        </li>

                        <li class="nav-item nav-7" value=7 onclick="handleListScroll(7)">Account Policies</li>
                        <li class="nav-item nav-8" value=8 onclick="handleListScroll(8)">Personal Information and Data</li>
                        <li class="nav-item nav-9" value=9 onclick="handleListScroll(9)">Fees</li>

                        <li class="nav-item nav-10" value=10 onclick="handleListScroll(10)">Confidentiality and Intellectual Property
                        </li>
					  <li class="nav-item nav-11" value=11 onclick="handleListScroll(11)">Disclaimers
                        </li>
					<li class="nav-item nav-12" value=12 onclick="handleListScroll(12)">Signature Consent
                        </li>
					<li class="nav-item nav-13" value=13 onclick="handleListScroll(13)">Right to Suspend and Terminate
                        </li>
						<li class="nav-item nav-13" value=13 onclick="handleListScroll(13)">Audit
                        </li>
                </ul>
            </div>
            <div class="col-xl-8 col-lg-7 col-sm-12 ">
                <div  class="scrollToTopBtn">
                <div class="common_heading">Terms and Condition</div>
                <div class="terms_content common_content privacy_description">
                    <p>
                   These terms of use (“Terms of Use”) constitute a legal agreement between you, the user (“User”, “You” or “Your”, which terms shall include the persons that access, use, and/or participate in the Platform in any manner), and Appreciate Platform Private Limited (including all its subsidiaries, associates and group entities, collectively referred as “Appreciate”, “We”, “Us” or “Company”), the owner of website located at https://www.appreciatecredit.com and https://www.moneylo.in (“Website”) and MoneyLo mobile application available on Apple AppStore and Google Play Store (“App”). Where the context so requires, the Website and the App shall be collectively referred to as the “Platform”. 
                    </p>
                    <p>The Company has established a privacy policy available at (“Privacy Policy”) that explains to the User how their information is collected and used. The Privacy Policy is referenced below and is hereby incorporated into the Terms of Use set forth herein. Your use of the Platform is governed also by the Privacy Policy. You hereby also acknowledge that any specific product or service availed by You on the Platform may have their own additional or supplemental terms and conditions and unequivocally consent to comply with and abide by such additional or supplemental terms and conditions. 
</p>
     <p>These Terms of Use, read with the Privacy Policy, shall be treated as an electronic record under the Information Technology Act, 2000 and the rules made thereunder and the amended provisions pertaining to electronic records under various Indian statutes and is enforceable against You under law by way of Your acceptance hereof. The Company reserves the right to change, modify, amend or update these Terms of Use and any other documents incorporated by reference herein at its sole discretion for complying with the extant legal and regulatory framework and for other legitimate business purposes at any time and the Company will post the amended Terms of Use with or without any notification to You on the Platform. It is Your responsibility to review the Terms of Use for any changes and You are encouraged to check the Terms of Use frequently. Your use of the Platform following any amendment of the Terms of Use will signify Your assent to and acceptance of any revised Terms of Use. Your usage of the Platform and availing of any Services provided by the Company on the Platform, shall be deemed acceptance to these Terms of Use (as may be changed, modified, amended or updated from time to time).
</p>
    
                </div>
            <div class="pp_accordion_blog_details">
                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3 id="section1">Eligibility
                    <span class="t-c-btn"></span>
                    </h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>You must be 18 years of age or older to visit or use the Platform in any manner. By visiting the Platform or accepting these Terms of Use, You represent and warrant to the Company that You are 18 years of age or older, and that You have the right, authority and capacity to use the Platform and agree to and abide by these Terms of Use. You also represent and warrant to the Company that You will use the Platform in a manner consistent with any and all applicable laws and regulations in addition to these Terms of Use.
</p>    
                    <p>You represent, acknowledge and agree that: (a) all registration information that You submit is truthful, current, complete and accurate, (b) You will maintain the currency, completeness and accuracy of such information, and (c) Your use of the Platform and the Services offered through the Platform do not violate any applicable law or regulation applicable either to You, the Platform or the Company. Your User Account may be terminated without warning if We, at Our discretion, believe that You are under the age of 18 (eighteen) or that You are not complying with any applicable laws, rules or regulations or these Terms of Use.
</p>
                </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section2">Description of Services <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>The Platform is a technology solution which enables Users to apply for Investment products as well as avail credit facilities from the Company’s or its affiliates’ authorized banking partners (“Services”). The Company’s scope of the Services is limited to facilitating the submission of an application by the User to the authorized banking partners as well as facilitating repayment or collection through physical and digital channels (including but not limited to through integration with banking partner’s or 3rd party payment gateway).  In relation to the Services, the Company may further provide certain ancillary services which shall be limited to facilitating the User’s opening of a current account with the banking partner. The Company may, through the Platform, provide the User with timely reminders through notifications, pop up banners, or any other means, reminders regarding the repayment of the loans availed through the Platform. The Platform may also, from time to time, display the total outstanding amounts payable by the User. It is hereby clarified that the Company does not provide its authorized banking partners with any underwriting or recovery services and that its scope of activities is limited to the scope of Services set out hereunder. </p>    
                    <p>We may at any time modify, alter, amend, increase or decrease the scope of Services. You may be signed up to additional accounts with the relevant financial intermediaries that provide execution services linked to the platform.  Each such intermediary is responsible for its own KYC and transaction, and the Platform does not make any warranties or provide any assurances for such KYC and transactions carried out by linked financial intermediaries. You are responsible for reading any additional terms and conditions required by other financial intermediaries and vetting the adequacy and appropriateness of these financial intermediaries and any services provided by them. By accepting these terms and conditions, You hereby release Us from all liability with respect to Your transactions and relationship with any other financial intermediary acknowledge that You have the choice not to use the Platform if You do not want to become a customer of any other financial intermediary linked to the Platform.</p>
			<p>
				The Company may, at its sole discretion, provide the Services in accordance with these Terms of Use, either by itself or through its affiliates. Nothing contained in these Terms of Use shall restrict the Company from delegating its obligations hereunder, either wholly or partly, to any of its affiliates without the prior consent of the User.
						</p>
                </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section3">Acceptance of Terms <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>These Terms of Use contain provisions that define Your limits, legal rights and obligations with respect to Your use of and participation in the Platform, including advertisements, third party applications and internet links and all content and Services available through the Platform. These Terms of Use shall also govern the transactions and interactions between You and other Users of the Platform. The Terms of Use described below incorporate the Privacy Policy and apply to all users of the Platform.</p>
                    <p>In addition to the Terms of Use, which governs Your access and use of the Platform, Your access to, use of, and participation in the Platform is subject to all applicable regulations, guidelines and additional policies that the Company may set forth from time to time, including without limitation, any product specific policy and any other restrictions or limitations that the Company publishes on the Platform (the “Additional Policies”). You hereby agree to comply with the Additional Policies and Your obligations thereunder at all times. You hereby acknowledge and agree that if You fail to adhere to any of the terms and conditions of these Terms of Use or the documents referenced herein, including any Additional Policies, the Company, in its sole discretion, may terminate Your User Account at any time without prior notice to You as well as initiate appropriate legal proceedings, if necessary.</p>    
                </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section4">License to Use<span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
						<p>
							The Company hereby grants You a non-exclusive, revocable, limited license to use the Platform in the manner and on the terms and conditions as set forth in these Terms of Use; provided, however, that: (i) You will not copy, distribute, or make derivative works of the Platform in any medium without the Company’s prior written consent; (ii) You will not alter or modify any part of the Platform other than as permitted and as may be reasonably necessary to use the Platform for its intended purposes; (iii) You will at all times act in accordance with the terms and conditions of the Terms of Use and in accordance with all applicable laws; and (iv) You may use third party software with the prior written approval of the Company and shall ensure that such third party software is duly licensed and installed.
						</p>
                    <p>
						All Intellectual Property complied or prepared by the User, either alone or jointly with any other person(s), which relate to or are connected to the BC/BF Services or the Services, will become the sole property of the Company. The User shall have no rights in respect of such Intellectual Property and shall make no claims in respect thereto. To the extent that any Intellectual Property is not already owned by the Company, the User hereby irrevocably and without any territorial limits assigns to the Company, for perpetuity, all such Intellectual Property created and/or generated by the User, either alone or with others for the purposes of and in respect of the Services and/or the BC/BF Services. All rights, title and interest in Intellectual Property, including the right to amend, alter, copy or commercially exploit the same, shall belong solely to, and be for the benefit of the Company. The User shall not, without prior written consent of the Company, use or copy any Intellectual Property for any purposes whatsoever other than as may be required for the purposes or in connection with the provision of the Services.
						</p>
                    </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section5">User Account<span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                   
                        <p>You need not register with the Company to simply visit and view the Platform, but to access and avail the Services of the Platform, You will need to create user account (“User Account”) protected through login credentials. To create a User Account, You must submit Your name, email address and such other details including credentials as may be requested through the User Account registration page on the Platform. You are solely responsible for safeguarding your credentials on the Platform and, if applicable, on the third-party sites linked to the Platform (collectively, "Credentials/s") and You shall keep Your Credentials secure at all times.</p>
                   
                        <p>You can, and are advised to, change Your passwords from time to time in order to keep Your User Account and Your interactions secured within the Platform. You shall be solely responsible for all activities that occur on Your User Account and You shall notify the Company immediately of any breach of security or any unauthorized use of Your User Account. Similarly, You shall never use another's User Account without the Company’s permission. You agree that You will not misrepresent Yourself or represent Yourself as another User of the Platform and/or the Services offered through the Platform.</p>
                   
                        <p>You hereby represent and warrant that any and all information and documents provided by You to the Company, or its agents shall be true, complete, free of mistakes and not misleading. You further undertake to promptly inform the Company in the event there are (i) any changes to the information or documents provided, or (ii) circumstances which have rendered such information or document untrue, incomplete, with errors, or misleading. If any of the information or documents are found to be untrue, incomplete, with errors, misleading or suffering from such other defect or deficiency which in the sole discretion of the Company renders such information or documents unreliable or unusable (provided that you have failed to promptly notify the Company), the Company reserves the right to (i) where the User Account has not been created, reject the User’s application to open the User Account, or (ii) where the User Account has been created, temporarily suspend or shut down such User Account. </p>
                    
                        <p>You can, and are advised to, change Your passwords from time to time in order to keep Your User Account and Your interactions secured within the Platform. You shall be solely responsible for all activities that occur on Your User Account and You shall notify the Company immediately of any breach of security or any unauthorized use of Your User Account. Similarly, You shall never use another's User Account without the Company’s permission. You agree that You will not misrepresent Yourself or represent Yourself as another User of the Platform and/or the Services offered through the Platform.</p>
                </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section6">Limitation of Liability<span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                        <p>Except where prohibited by law, in no event will the Company, its directors, employees, agents, associates, partners or suppliers be liable to You for any indirect, consequential, exemplary, incidental or punitive damages, including loss of profit or loss of revenue, even if the Company has been advised of the possibility of such damages. Further, it is hereby clarified that in no event will the Company, its directors, employees, agents, associates, partners, or suppliers, be held liable for the disclosure of the any of the User’s information to any third party as long as such disclosure is in compliance with Clause 9 of the Terms of Use. </p>   
                      <p>
						  You hereby expressly acknowledge and agree that You (and not the Company) will be liable for Your losses, damages etc. (whether direct or indirect) caused by an unauthorized use of Your User Account. Notwithstanding the foregoing, You may be liable for the losses of the Company or others due to such unauthorized use and We will not be responsible for misuse of Your User Account by any third party, whether authorized by You or not. In no event shall the Company be individually liable to You for any damages for breach of fiduciary duty by third-parties.
						</p>
						<p>
							In the event the Company is found to be liable to You for any damage or loss which arises out of or is in any way connected with Your use of the Platform, the Company’s liability shall in no event exceed the total value of any service fees connected with Your User Account paid in the 3 (three) months prior to the date of the initial claim made against the Company.
						</p>
                    </div>  
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section7">Account Policies<span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
						<p>
							You acknowledge and agree that You shall comply with the following policies (the “Account Policies”):
						</p>
                        <ol class="common_content inner_list_number">
                     <li>
                        <p>You shall not use any automated system, including but not limited to, ‘robots’, ‘spiders’, ‘offline readers’, ‘scrapers’ etc., to access the Platform, for any purpose, without the Company’s prior written approval.</p>
                     </li>
                    <li>
                        <p>You shall not, other than as required for the provision of the BC/BF Services, in any manual or automated manner collect information, personal or otherwise, of any other User through the Platform including but not limited to, names, addresses, phone numbers, or email addresses, copying copyrighted text or content, or otherwise misuse or misappropriate the Platform’s information or content, including but not limited to, use on a ‘mirrored’, competitive, or third party website, except with the prior written consent of the Company or through a lawful and valid communication with such other User through any valid communication channel provided on the Platform. You shall not take any action that: (i) unreasonably encumbers or, in the Company’s sole view, may unreasonably encumber the Platform’s infrastructure; (ii) interferes or attempts to interfere with the proper working of the Platform or any third-party participation on the Platform; or (iii) bypasses the Company’s measures that are used to prevent or restrict access to the Platform.</p>
                    </li>
					<li>
                        <p>You shall not frame or hotlink or deep link any contents from the Platform.</p>
                     </li>
					<li>
						<p>
							You shall not take any action that: (i) unreasonably encumbers or, in the Company’s sole view, may unreasonably encumber the Platform’s infrastructure; (ii) interferes or attempts to interfere with the proper working of the Platform or any third-party participation on the Platform; or (iii) bypasses the Company’s measures that are used to prevent or restrict access to the Platform.
						</p>		
					</li>
					<li>
						<p>
						You agree to neither collect nor harvest any personally identifiable data, including without limitation, names or other User Account information, from the Platform, nor to use the communication systems provided by the Platform for any use other than as intended under the Platform and in accordance with the Privacy Policy.
						</p>
					</li>
					<li>
						<p>
						You agree that the opening and maintenance of Your account on the Platform will be subject to the rules and regulations prescribed by the Reserve Bank of India and any other regulatory authority.
						</p>
					</li>
					<li>
						<p>
						You agree to receive all updates and alerts via messages or notifications to your registered mobile number and email address. The delivery of such updates and alerts will be done by the Company on a best-effort basis through its official channels. 
						</p>
					</li>
						<li>
						<p>
						You understand and agree to pay to the Company such fees as may be applicable from time to time for using the Platform and availing its services. These fees shall be revised on the basis of factors including the prevalent market conditions and such revisions shall be displayed within the ‘price transparency’ section of the Platform. You acknowledge that that the Platform may engage third-party entities to provide the User with information regarding the features and services provided by the Platform, assist the User with their on-boarding process and provide additional enhanced support at the option of the User. You hereby agree that additional fees may be charged (as set out in the ‘price transparency’ section) for availing such enhanced support services from third-party entities.
						</p>
					</li>
                    </ol>
                    </div>  
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section8">Personal Information and Data <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                       <p>In order to ensure that the User can access the various features and use the Services provided by the Company, the User shall be required to mandatorily submit certain personal information to ensure compliance with prevalent ‘Know Your Customer’ (“KYC”) regulations, the Prevention of Money Laundering Act, 2002 and the Information Technology (Reasonable Security Practices and Procedures and Sensitive Personal Information) Rules, 2011. The User shall be required to provide express consent to the Company for granting it access to information during various stages of the User’s interaction with the Company and the Platform, including but not limited to the following:  </p>
						<ol>
							<li>
								<p>
									name of User, date of birth, gender, nationality, mother and father’s names, marital status and a recent, updated photo; 
								</p>
							</li>
							<li>
								<p>
									residential address, phone number, email address and nominee details; 
								</p>
							</li>
							<li>
								<p>
									bank account number and IFSC Code of bank branch; 
								</p>
							</li>
								<li>
								<p>
								PAN Card, redacted Aadhar number, GST Number, business related information and other KYC information collected through online or offline means; 
								</p>
							</li>
								<li>
								<p>
									employment related details such as occupation, income, employer details, designation; and
								</p>
							</li>
							<li>
								<p>
									information stored on device such as telephonic records, device information, cookies. 
								</p>
							</li>
						</ol>
						<p>
							The information provided by the User shall be stored and utilized in accordance with the relevant applicable regulations. The User hereby authorizes the Company to use any data provided by the User to the Company and the Platform for, including but not limited to, provision of the Services as set out above and any other ancillary services such as provision of personalised offers and product recommendations (through Your registered e-mail address or calls or messages to Your registered mobile number or via notifications or recommendations on the Platform). 
						</p>
						<p>
							The User hereby also authorizes the Company to disclose such information to any third party that the Company deems necessary and essential for the provision of its Services and any other ancillary services, including in relation to its advertising campaigns. 
						</p>
						<p>
							In the event the User already has an existing user account for availing services from any affiliate of the Company, the User hereby agrees that the Company may use the information provided by the User to such affiliate for the provision of the Services as contemplated hereunder. 
						</p>
						<p>
							The Company reserves the right to, and the User hereby consents to the Company procuring additional User information from third parties including but not limited to account aggregators, NSDL, UIDAI, GST Portal and Credit bureaus. The User agrees to cooperate with the Company or its affiliates, and provide any requisite consents required for obtaining additional information from third parties as specified above.
						</p>
                    </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section9">Fees <span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                        <p>In consideration of Company making available the Platform and the Services to You, it shall be entitled to a service fees ("Company Service Fee") as may be intimated by Company from time to time. Company shall also be entitled to receive/deduct any other service fee from You for any services provided by the Company to You as may be intimated by Company from time to time.</p>     
						<p>
							The User shall be allowed to set up automated payment instructions which enables them to pay the Company Service Fee payable to the Company after fixed time intervals as determined by the Company (weekly, monthly, or quarterly). 
						</p>
						<p>
							The User shall be responsible for payment of its own Taxes, of whatever nature, in respect of all sums payable by Company to the User under this Agreement. In relation to certain Services, Retailer Partner may be required to maintain such security deposit as may be intimated by Company and/or the User from time to time.
						</p>
                    </div>
					</div></div>

                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section10">Confidentiality and Intellectual Property<span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>For the purposes of these Terms of Use, the term ‘Confidential Information’ shall mean all information (whether oral or recorded in any medium) relating to the business, financial or other affairs (including future plans) of the Company it affiliates and the User which is treated by the Company, as confidential, or is marked or is by its nature confidential, including but not limited to all Intellectual Property belonging to the Company, their affiliates or any of the other users or business partners as the case may be, together with the existence and contents of any other agreements (including all Schedules) that the Company or its affiliates may enter into with the User, and any ancillary documents. The term ‘Intellectual Property’ shall mean all intellectual property used for the purpose of or in association with or in relation to providing Company Services utilizing the Platform and includes without limitation (a) Software, operating manuals, software code, program, instructions, specifications, processes, input methods, data or information used in relation to, in association with or for the operation of the software installed by Company; (b) the trademarks, service marks, trade names, business names, logos, symbols, styles, colour combinations used by Company during the course of its business and all depictions, derivations and representations thereof; (c) all promotional material including without limitation, advertisements, literature, graphics, images, content and the look and feel of all of the above; (d) all information, data or material in whatever form, whether tangible or not, provided by Company to the User during the course of or in relation to the Services; and (e) all techniques, formulae, patterns, compilations, processes, inventions, practices, methodology, techniques, improvement, utility model, procedures, designs, skills, technical information, notes, experimental results, service techniques, samples, specifications of the products or services, labelling specifications, rights on software, and any other knowledge or know-how of any nature whatsoever. </p>
					<p>
						The User acknowledges that the Confidential Information and all other confidential or proprietary information with respect to the business and operations of the Company and related entities are valuable, special, and unique assets of the Company. Accordingly, the User agrees not to, at any time whatsoever either during or after the term of their engagement with the Company, directly or indirectly, to any Person, use or authorize any Person to use, any Confidential Information without the prior written consent of the Company.
						</p>
						<p>
							The User shall not publicise, disclose or allow disclosure of any information about the Company, its present or former directors, officers, employees, agents or consumers, or their business and financial affairs, personnel matters, operating procedures, organisation responsibilities, marketing matters and policies or procedures, with any third party, or take any other action seeking to publicise or disclose any such information in any way likely to result in such information being made available to the general public in any form, including books, articles or writings of any other kind, as well as film, videotape, audiotape or any other medium.
						</p>
						<p>
							The User shall use the same degree of care to protect the Confidential Information and the information of the consumers as it uses to protect its own Confidential Information of like nature, but in no circumstances, with less than reasonable care. 
						</p>
						<p>
							The User may disclose the Confidential Information in response to a valid court order, law, rule, regulation, or other governmental action, provided that the Company is notified in writing prior to disclosure of the information to permit the Company to oppose such disclosure by appropriate legal action. 
						</p>
						<p>
							Upon termination or expiration of this Agreement or upon the earlier request of the Company, the User shall, at no additional cost, (i) promptly return to the Company all Confidential Information including but not limited to copies of documents, papers or other material which may contain or be derived from the Confidential Information, which are in its possession or control; or (ii) upon written request from the Company, destroy such Confidential Information and provide the Company with written certification of such destruction. Upon termination or expiration of this Agreement, the User shall cease all further use of any Confidential Information, whether in tangible or intangible form.
						</p>
						<p>
							The User acknowledges that its failure to comply with the provisions of this provision may cause irreparable harm to the Company which cannot be adequately compensated for in damages and accordingly acknowledges that the Company will be entitled to claim, in addition to any other remedies available to it, interlocutory and permanent injunctive relief to restrain any anticipated, threatened, present or continuing breach of its confidentiality obligations.
						</p>
                    </div>
					</div></div>
               
                <div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section11">Disclaimers<span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>The User understands that the Services provided by the Platform is on an ‘as is’ basis. The User shall use the Platform at their own risk. The Company makes no warranty regarding the use of the Platform being bug free, virus free, error free and free of any technical problems. The Company does not warrant that all errors, bugs, or defects shall be corrected. </p>
						<p>
							The Company is not an agent or broker for any products provided on the Platform. The Company does not, under any circumstances, provide any financial, tax, and/or legal advice of any kind. The User shall not hold liable, the Company, its directors, employees, agents, associates, partners, or suppliers liable for any trading or investment losses incurred by the User.  
						</p>
                       <p>
						   The Company disclaims all warranties, conditions, results, guarantees, and representations with respect to the Platform, whether express or implied, the warranties of merchantability or satisfactory quality, fitness for a particular purpose, non-infringement of third-party rights or arising from the course of performance or of dealing or usage of trade. 
						</p>
						<p>
							All lending products applied for through the Platform shall be subject to market risks. Please do your due diligence and research before applying and read all related documents carefully. 
						</p>
						<p>
							Any interactions, communications, dealings or transactions between the User and third-party providers on the Platform regarding the products or schemes provided by the third-party shall constitute a separate and independent transaction between the User and such third-party and under no circumstance shall any liability arising from such transactions be imposed on the Company or the Platform.
						</p>
						</div></div>
                </div>
				
				<div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section12">Signature Consent<span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>The User consents for the Company and the Platform to link any signatures provided as part of the Platform onboarding process, to such User’s registered email address, provided to create such User’s User Account on the Platform, and use the same for the purpose of such User’s digital signature.</p>
					
						</div></div>
                </div>
				
				<div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section13">Right to Suspend and Terminate<span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>The User hereby agreed and acknowledges that the Company shall have the right to suspend or terminate the User’s User Account or the provision of the Services at its sole discretion, if the User has in the sole discretion of the Company: </p>
					<ul>
						<li>
							<p>
								violated or is likely to violate the terms of these Terms of User or any other agreement it has with Company or any of the Company Rules; 
							</p>
						</li>
						<li>
							<p>
								in the event of a change in control of the User; 
							</p>
						</li>
						<li>
							<p>
								violated or is likely to violate any of the applicable law; 
							</p>
						</li>
						<li>
							<p>
								provided any false, incomplete, inaccurate or misleading information or otherwise engaged in fraudulent or illegal conduct;
							</p>
						</li>
						<li>
							<p>
								if Company is mandated to do so under applicable law and instructions from governmental authority;
							</p>
						</li>
						<li>
							<p>
								for recovery of any of its dues under the Agreement;
							</p>
						</li>
						<li>
							<p>
								for any suspected violation of any rules, regulations, orders, directions, notifications issued by Governmental Authority from time to time;
							</p>
						</li>
						<li>
							<p>
								for any discrepancy or suspected discrepancy in the particulars or documentation provided by consumers or the User;
							</p>
						</li>
						<li>
							<p>
								due to technical failure, modification, upgradation, variation, relocation, repair, and/or maintenance due to any emergency or for any technical reasons;
							</p>
						</li>
						<li>
							<p>
								for any other reason that Company deems appropriate in the best interests of business.
							</p>
						</li>
					</ul>
						<p>
							The User agrees and acknowledges that Company reserves the right at any time to (without notice to the User) set off and apply any or all sums due and payable by Company to the User under this Agreement, and/or any or all sums of money held in accounts with Company and or its business partners against:
						</p>
						<ul>
						<li>
							<p>
								any or all sums due and payable by the User to the Company under these Terms of Use;							</p>
						</li>
						<li>
							<p>
								the amount of any liability incurred by the User against Company under these Terms of Use;
							</p>
						</li>
						<li>
							<p>
								any amount erroneously paid to the User by Company and/or its business partners; and/or 
							</p>
						</li><li>
							<p>
								any statutory liability of the User including payment of applicable taxes that the User has failed to pay to the relevant governmental authorities. 
							</p>
						</li>
						</ul>
						</div></div>
                </div>
					<div class="content_heading">
					<div class="privacy_privacy_title pp_accordion_blog_details-item">
                    <h3  id="section14">Audit<span class="t-c-btn"></span></h3>
					</div>
					<div class="privacy_policy_tab">
                    <div class="terms_content common_content answer">
                    <p>The Company shall be entitled to conduct audits of the User through internal or external auditors, or by agents appointed by the Company, in accordance with applicable law or any other regulatory requirement and to obtain copies of any audit or review reports made on the User. The User shall cooperate with the Company’s auditors (internal or external) to ensure a prompt and accurate audit. The costs of all such audits shall be borne by the Company. </p>
					<p>
						In the event of an audit by any of the regulatory authorities, including but not limited to the Reserve Bank of India, the User shall, at all times, ensure that it completely cooperates with such regulatory bodies by ensuring timely access to all documents, records and other necessary information.
						</p>
						</div></div>
                </div>
				
				
				
                </div>
                </div>
        </div>
    </div>
		</div></section>
	<!-- ================================================
           Terms and condition Section End
=====================================================-->

<!-- ================================================
   Modal pop up section start
=====================================================-->

<div class="custom-model-main">
    <div class="custom-model-inner container">
         <div class="close-btn">×</div>
        <div class="row">
            <div class="col-xl-6">
                <div class="model_contact_details">
               <div class="common_heading">
               We would love to hear from you
               </div> 
               <div class="modal_custom_content">
               Have something nice or not so nice to say? Do you have any questions? Reach out to us, we’d love to start a dialogue with you.
               </div>
               <ul class="mail_list">
                <li class="mail_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/mail.svg" alt="">
                </li>
                    <li class="mail_text"><a target="_blank" href="mailto:helpdesk@ppreciate.com">helpdesk@appreciate.com</a></li>
               </ul>
               <ul class="call_list">
                <li class="call_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/call.svg" alt="">
                </li>
                <li class="call_text"><a href="tel:+91-7039325849">+91 70393 25849</a><br><span>(9 am to 9 pm)</span></li>
               </ul>
               </div>
               <div class="model_left_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/contact_box.png" alt="">
               </div>
            </div>
            <div class="col-xl-6">
                <div class="modal_form">
                	 <?php echo do_shortcode('[contact-form-7 id="395c14b" title="Contact form"]');?>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-overlay"></div>
</div>  
<!-- ================================================
   Modal pop up section end
=====================================================-->


<?php get_footer();?>



<?php get_footer();?>