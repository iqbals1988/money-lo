<?php

/*
Template Name: Blog Detail Page
*/

get_header();
?>

<!-- ================================================
    Breadcum Section start
=====================================================-->
<section class="blog_details_section">
    <div class="container">
        <div class="blog_breadcum common_content">
            <ul class="breadcum_div">
                <li>
                    <h3>
                        <a href="<?php echo get_site_url(); ?>/blog/">Blog</a>
                    </h3>
                </li>
                <li><span class="breadcum_arrow">/</span></li>
                <li>
                    <h3>
                        <a href="#">Business Loans</a>
                    </h3>
                </li>
                <li><span class="breadcum_arrow">/</span></li>
                <li>
                    <h3>
                        <span>How can timely credit supercharge your business growth?</span>
                    </h3>
                </li>
            </ul>
        </div>
    </div>
</section>
<!-- ================================================
    Breadcum Section end
=====================================================-->


<!-- ================================================
    Banner Section start
=====================================================-->
<section class="blog_banner_section">
    <div class="container">
        <div class="blog_banner_img">
        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/blog_banner.jpg" alt="">
        </div>
    </div>
</section>
<!-- ================================================
    Banner Section end
=====================================================-->

<!-- ================================================
   Blog content section start
=====================================================-->
<section class="blog_content_section">
    <div class="container">
        <div class="custom_container">
            <div class="content_main">
                <div class="content_div">
                    <div class="common_heading top_content">How can timely credit supercharge your business growth?</div>
                    <div class="content_career common_content">
                        <h2>How to make a career change</h2>
                        <p>Making a career change usually means investing both your time and money. As with any investment, it's important to be informed before making a decision. Before you make a career change, here are steps you can take to increase your chances of success.</p>
                        <div class="heading_para common_content">
                            <h4>Assess Yourself</h4>
                            <p>There are several advantages to moving to a multi-cloud strategy, from bolstering system resilience to increasing organizational flexibility. Let’s take a more in-depth look at a few of these benefits.</p>
                        </div>

                        <div class="heading_para common_content">
                            <h4>Make a List of Occupations to Explore</h4>
                            <p>One of the most important aspects of building an application is ensuring that it is reliable and available. Multi-cloud architectures help organizations avoid downtime by providing teams with the resources they need to keep their services running when one cloud provider experiences an outage or other major disruption.</p>
                        </div>

                        <div class="heading_para common_content">
                            <h4>Make a List of Occupations to Explore</h4>
                            <p>As they compete with one another for business, cloud providers regularly innovate and refine their offerings to better meet the needs of development organizations. An organization that leverages the services of multiple cloud providers is in a better position to take advantage of these advancements. This will help move the business forward by enabling developers to continually innovate without worrying about the limitations of any one individual cloud provider.</p>
                        </div>

                        <div class="heading_para common_content">
                            <h4>Explore the Occupations on Your List</h4>
                            <p>Locking yourself into a particular cloud vendor can be problematic for several reasons. As mentioned above, the provider may not be capable of effectively running a newly-minted application. In addition, the quality of the service that the cloud vendor provides may decline over time. If such a situation occurs (and an organization is unprepared to leverage another cloud service), the damage to the business can be severe. A multi-cloud strategy inherently reduces your organization’s dependence on any one particular vendor.</p>
                        </div>
                    </div>

                    <div class="blog_person">
                        <div class="person_img">
                            <img src="images/blog_person.png" alt="">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/blog_person.png" alt="">
                        </div>
                        <div class="person_content common_content heading_para">
                            <h4>By Subho Moulik, Team Appreciate</h4>
                            <p>Subho Moulik is on the Board of Appreciate.  He is passionate about investing and helping every person create wealth for themselves and their family.</p>                        </div>
                    </div>

                </div>

                <div class="Blog_social_icon">
                    <ul class="social_icon">
                        <li>
                            <a href="!#">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/facebook.png" alt="">
                            </a>
                        </li>
                        <li>
                            <a href="!#">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/twiter.png" alt="">
                            </a>
                        </li>
                        <li>
                            <a href="!#">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/linkedin.png" alt="">
                            </a>
                        </li>
                        <li>
                            <a href="!#">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/chain.png" alt="">
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ================================================
   Blog content section end
=====================================================-->
   <!-- ================================================
            Join growing tribe Section Start
=====================================================-->
<section class="join_tribe_section">
    <div class="container">
    <div class="common_heading top_content">Join the growing tribe of 2,00,000+ Appreciators</div>

    <div class="google_app_btn">
                <a href="#" class="Googleplaystore">
                <img src="<?php echo get_template_directory_uri(); ?>/images/Googleplaystore.webp" alt="">
                </a>
                <a href="#" class="app_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/AppStore.webp" alt="">
                </a>
            </div>
</section>
   <!-- ================================================
            Join growing tribe Section End
=====================================================-->
	<!-- ================================================
            Terms Condition Section End
=====================================================-->

<!-- ================================================
   Modal pop up section start
=====================================================-->

<div class="custom-model-main">
    <div class="custom-model-inner container">
         <div class="close-btn">×</div>
        <div class="row">
            <div class="col-xl-6">
                <div class="model_contact_details">
               <div class="common_heading">
               We would love to hear from you
               </div> 
               <div class="modal_custom_content">
               Have something nice or not so nice to say? Do you have any questions? Reach out to us, we’d love to start a dialogue with you.
               </div>
               <ul class="mail_list">
                <li class="mail_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/mail.svg" alt="">
                </li>
                    <li class="mail_text"><a target="_blank" href="mailto:helpdesk@ppreciate.com">helpdesk@appreciate.com</a></li>
               </ul>
               <ul class="call_list">
                <li class="call_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/call.svg" alt="">
                </li>
                <li class="call_text"><a href="tel:+91-7039325849">+91 70393 25849</a><br><span>(9 am to 9 pm)</span></li>
               </ul>
               </div>
               <div class="model_left_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/contact_box.png" alt="">
               </div>
            </div>
            <div class="col-xl-6">
                <div class="modal_form">
                	 <?php echo do_shortcode('[contact-form-7 id="395c14b" title="Contact form"]');?>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-overlay"></div>
</div>  
<!-- ================================================
   Modal pop up section end
=====================================================-->


<?php get_footer();?>