<?php

/*
Template Name: Blog Page
*/

get_header();
?>


    <!-- ================================================
    Banner Section start
=====================================================-->
<section class="bloglisting_banner_section">
        <div class="container">
            <div class="blog_banner_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/blog_banner.jpg" alt="">
                <div class="banner_bottom_txt">
                    <div class="banner_bottom_cnt">
                        <span class="list_date">31 July 2022</span>
                        <h3>How can timely credit supercharge your business growth?</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ================================================
    Banner Section end
=====================================================-->

    <!-- ================================================
   Blog content section start
=====================================================-->
    <section class="blog_listing_section">
        <div class="container">
            <ul class="blog_filter" id="filters">
                <li class="clickme"><a href="javascript:void();" data-tag="all" class="activelink">All</a></li>
                <li class="clickme"><a href="javascript:void();" data-tag="topic1">Business Registration</a>
                </li>
                <li class="clickme"><a href="javascript:void();" data-tag="topic2">Business Loans</a>
                </li>
                <li class="clickme"><a href="javascript:void();" data-tag="topic3">Growth Ideas</a>
                </li>
                <li class="clickme"><a href="javascript:void();" data-tag="topic4">Top Trends</a>
                </li>
            </ul>

            <div class="blog_list_part blog-loadmore-wapper" id="all">

                <div class="blog_list_left_main">
                    <a href="<?php echo get_site_url(); ?>/blog-details/">
                        <div class="image_blog_list">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">31 July 2022</span>
                            <h2>What Is Compounding and Why Is It Important?</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                     <a href="<?php echo get_site_url(); ?>/blog-details/">
                        <div class="image_blog_list">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-1.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">23 July 2022</span>
                            <h2>FDIC and SIPC Insurance: What’s the Difference?</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                         <a href="<?php echo get_site_url(); ?>/blog-details/">
                        <div class="image_blog_list">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-2.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">21 July 2022</span>
                            <h2>Why You Should Keep Investing When the Market Is Volatile</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-3.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">31 July 2022</span>
                            <h2>What Is Compounding and Why Is It Important?</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-4.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">23 July 2022</span>
                            <h2>FDIC and SIPC Insurance: What’s the Difference?</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-5.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">21 July 2022</span>
                            <h2>Why You Should Keep Investing When the Market Is Volatile</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-6.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">31 July 2022</span>
                            <h2>What Is Compounding and Why Is It Important?</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-7.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">23 July 2022</span>
                            <h2>FDIC and SIPC Insurance: What’s the Difference?</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-8.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">21 July 2022</span>
                            <h2>Why You Should Keep Investing When the Market Is Volatile</h2>
                        </div>
                    </a>
                </div>

            </div>

            <div class="blog_list_part hide" id="topic1">

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-2.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">21 July 2022</span>
                            <h2>Why You Should Keep Investing When the Market Is Volatile</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-3.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">31 July 2022</span>
                            <h2>What Is Compounding and Why Is It Important?</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-4.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">23 July 2022</span>
                            <h2>FDIC and SIPC Insurance: What’s the Difference?</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-5.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">21 July 2022</span>
                            <h2>Why You Should Keep Investing When the Market Is Volatile</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-6.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">31 July 2022</span>
                            <h2>What Is Compounding and Why Is It Important?</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-7.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">23 July 2022</span>
                            <h2>FDIC and SIPC Insurance: What’s the Difference?</h2>
                        </div>
                    </a>
                </div>

                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-8.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">21 July 2022</span>
                            <h2>Why You Should Keep Investing When the Market Is Volatile</h2>
                        </div>
                    </a>
                </div>

            </div>

            <div class="blog_list_part hide" id="topic2">
                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-5.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">21 July 2022</span>
                            <h2>Why You Should Keep Investing When the Market Is Volatile</h2>
                        </div>
                    </a>
                </div>
            </div>

            <div class="blog_list_part hide" id="topic3">
                <div class="blog_list_left_main">
                    <a href="">
                        <div class="image_blog_list">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/blog_img/Mask Group-8.webp" alt="">
                        </div>
                        <div class="blog_list_cnt">
                            <span class="list_date">21 July 2022</span>
                            <h2>Why You Should Keep Investing When the Market Is Volatile</h2>
                        </div>
                    </a>
                </div>
            </div>

            <div class="blog_list_part hide" id="topic4">
                <p>No Blog Found</p>
            </div>

            <ul class="pagination">
                <li>
                    <a href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" width="61" height="16" viewBox="0 0 61 16" fill="none">
                            <path d="M0.292892 7.61491C-0.0976333 8.00544 -0.0976334 8.6386 0.292892 9.02913L6.65685 15.3931C7.04738 15.7836 7.68054 15.7836 8.07107 15.3931C8.46159 15.0026 8.46159 14.3694 8.07107 13.9789L2.41421 8.32202L8.07107 2.66517C8.46159 2.27464 8.46159 1.64148 8.07107 1.25095C7.68054 0.860427 7.04738 0.860427 6.65685 1.25095L0.292892 7.61491ZM61 7.32202L1 7.32202L1 9.32202L61 9.32202L61 7.32202Z" fill="#605EBC"/>
                          </svg>
                    </a>
                </li>
                <li>
                    <a href="#" class="active">1</a>
                </li>
                <li>
                    <a href="#">2</a>
                </li>
                <li>
                    <a href="#">3</a>
                </li>

                <li>
                    <a href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" width="61" height="16" viewBox="0 0 61 16" fill="none">
                            <path d="M60.7071 7.61491C61.0976 8.00544 61.0976 8.6386 60.7071 9.02913L54.3431 15.3931C53.9526 15.7836 53.3195 15.7836 52.9289 15.3931C52.5384 15.0026 52.5384 14.3694 52.9289 13.9789L58.5858 8.32202L52.9289 2.66517C52.5384 2.27464 52.5384 1.64148 52.9289 1.25095C53.3195 0.860427 53.9526 0.860427 54.3431 1.25095L60.7071 7.61491ZM-4.37114e-08 7.32202L60 7.32202L60 9.32202L4.37114e-08 9.32202L-4.37114e-08 7.32202Z" fill="#605EBC"/>
                          </svg>
                    </a>
                </li>
            </ul>
        </div>
    </section>

   <!-- ================================================
   Blog content section end
=====================================================-->


    
   <!-- ================================================
            Join growing tribe Section Start
=====================================================-->
<section class="join_tribe_section">
    <div class="container">
    <div class="common_heading top_content">Join the growing tribe of 2,00,000+ Appreciators</div>

    <div class="google_app_btn">
                <a href="#" class="Googleplaystore">
                <img src="<?php echo get_template_directory_uri(); ?>/images/Googleplaystore.webp" alt="">
                </a>
                <a href="#" class="app_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/AppStore.webp" alt="">
                </a>
            </div>
</section>
   <!-- ================================================
            Join growing tribe Section End
=====================================================-->
	
	<!-- ================================================
            Terms Condition Section End
=====================================================-->

<!-- ================================================
   Modal pop up section start
=====================================================-->

<div class="custom-model-main">
    <div class="custom-model-inner container">
         <div class="close-btn">×</div>
        <div class="row">
            <div class="col-xl-6">
                <div class="model_contact_details">
               <div class="common_heading">
               We would love to hear from you
               </div> 
               <div class="modal_custom_content">
               Have something nice or not so nice to say? Do you have any questions? Reach out to us, we’d love to start a dialogue with you.
               </div>
               <ul class="mail_list">
                <li class="mail_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/mail.svg" alt="">
                </li>
                  <li class="mail_text"><a target="_blank" href="mailto:helpdesk@ppreciate.com">helpdesk@appreciate.com</a></li>
               </ul>
               <ul class="call_list">
                <li class="call_icon">
                <img src="<?php echo get_template_directory_uri(); ?>/images/call.svg" alt="">
                </li>
                <li class="call_text"><a href="tel:+91-7039325849">+91 70393 25849</a><br><span>(9 am to 9 pm)</span></li>
               </ul>
               </div>
               <div class="model_left_img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/contact_box.png" alt="">
               </div>
            </div>
            <div class="col-xl-6">
                <div class="modal_form">
                	 <?php echo do_shortcode('[contact-form-7 id="395c14b" title="Contact form"]');?>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-overlay"></div>
</div>  
<!-- ================================================
   Modal pop up section end
=====================================================-->


<?php get_footer();?>